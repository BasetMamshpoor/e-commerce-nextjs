"use client";

import * as React from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  Search,
  ShoppingCart,
  User,
  Menu,
  X,
  Sparkles,
  Home,
  Grid,
  Heart,
  Bell,
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import {
  Drawer,
  DrawerContent,
  DrawerHeader,
  DrawerTitle,
} from "@/components/ui/drawer";
import { ThemeToggle } from "./theme-toggle";
import { CartBadge } from "./cart-badge";
import { NotificationBell } from "./notification-bell";
import { CategoryNavMenu } from "./category-nav-menu";
import { useAuth } from "@/providers/auth-context";
import { APP_NAME } from "@/constants/app";
import { cn } from "@/lib/utils";

export function Header() {
  const router = useRouter();
  const { isAuthenticated, user } = useAuth();
  const [searchQuery, setSearchQuery] = React.useState("");
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);
  const [searchDrawerOpen, setSearchDrawerOpen] = React.useState(false);

  const onSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;
    router.push(`/products?search=${encodeURIComponent(searchQuery.trim())}`);
    setSearchDrawerOpen(false);
    setMobileMenuOpen(false);
  };

  const isAdmin = isAuthenticated && ["ADMIN", "EDITOR", "SUPPORT"].includes(user?.role ?? "");

  return (
    <>
      <header className="sticky top-0 z-40 border-b border-border bg-background/95 backdrop-blur-md supports-[backdrop-filter]:bg-background/80">
        {/* Top bar (desktop) */}
        <div className="hidden border-b border-border/60 bg-muted/30 lg:block">
          <div className="container-site flex h-9 items-center justify-between text-xs text-muted-foreground">
            <span className="flex items-center gap-1.5">
              <Sparkles className="size-3.5 text-primary" />
              ارسال رایگان برای سفارش‌های بالای ۵۰۰٬۰۰۰ تومان
            </span>
            <div className="flex items-center gap-4">
              <Link href="/tracking" className="hover:text-foreground transition-colors">
                پیگیری سفارش
              </Link>
              <Link href="/tickets" className="hover:text-foreground transition-colors">
                پشتیبانی
              </Link>
              <Link href="/about" className="hover:text-foreground transition-colors">
                درباره ما
              </Link>
            </div>
          </div>
        </div>

        {/* Main bar */}
        <div className="container-site flex h-16 items-center gap-3">
          {/* Mobile menu */}
          <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="lg:hidden" aria-label="منو">
                <Menu className="size-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-full p-0 sm:w-96">
              <SheetHeader className="border-b border-border p-4">
                <SheetTitle className="text-right">منو</SheetTitle>
              </SheetHeader>
              <nav className="flex flex-col gap-1 p-3 text-sm">
                <MobileLink href="/" onClick={() => setMobileMenuOpen(false)}>خانه</MobileLink>
                <MobileLink href="/products" onClick={() => setMobileMenuOpen(false)}>همه محصولات</MobileLink>
                <MobileLink href="/categories" onClick={() => setMobileMenuOpen(false)}>دسته‌بندی‌ها</MobileLink>
                <MobileLink href="/brands" onClick={() => setMobileMenuOpen(false)}>برندها</MobileLink>
                <MobileLink href="/products?hasDiscount=true" onClick={() => setMobileMenuOpen(false)}>تخفیف‌دارها</MobileLink>
                <MobileLink href="/blog" onClick={() => setMobileMenuOpen(false)}>وبلاگ</MobileLink>
                <div className="my-2 h-px bg-border" />
                <MobileLink href="/cart" onClick={() => setMobileMenuOpen(false)}>سبد خرید</MobileLink>
                {isAuthenticated ? (
                  <>
                    <MobileLink href={isAdmin ? "/admin" : "/account"} onClick={() => setMobileMenuOpen(false)}>
                      {isAdmin ? "پنل مدیریت" : "حساب کاربری"}
                    </MobileLink>
                    <MobileLink href="/account/orders" onClick={() => setMobileMenuOpen(false)}>سفارش‌های من</MobileLink>
                    <MobileLink href="/account/wallet" onClick={() => setMobileMenuOpen(false)}>کیف پول</MobileLink>
                    <MobileLink href="/account/tickets" onClick={() => setMobileMenuOpen(false)}>تیکت‌ها</MobileLink>
                    <MobileLink href="/account/notifications" onClick={() => setMobileMenuOpen(false)}>نوتیفیکیشن‌ها</MobileLink>
                  </>
                ) : (
                  <MobileLink href="/login" onClick={() => setMobileMenuOpen(false)}>ورود / ثبت‌نام</MobileLink>
                )}
              </nav>
            </SheetContent>
          </Sheet>

          {/* Logo */}
          <Link href="/" className="flex items-center gap-2.5 transition-transform hover:scale-105" aria-label={APP_NAME}>
            <span className="flex size-10 items-center justify-center rounded-xl bg-primary text-primary-foreground shadow-md shadow-primary/20">
              <ShoppingCart className="size-5" />
            </span>
            <span className="hidden text-lg font-bold text-foreground sm:inline">
              {APP_NAME}
            </span>
          </Link>

          {/* Search (desktop) */}
          <form onSubmit={onSearch} className="hidden flex-1 lg:block">
            <div className="relative">
              <Search className="pointer-events-none absolute right-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                type="search"
                placeholder="جست‌وجو در محصولات..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pr-9"
              />
            </div>
          </form>

          {/* Actions */}
          <div className="mr-auto flex items-center gap-1 lg:mr-0">
            {/* Mobile search trigger */}
            <Button
              variant="ghost"
              size="icon"
              className="lg:hidden"
              aria-label="جست‌وجو"
              onClick={() => setSearchDrawerOpen(true)}
            >
              <Search className="size-5" />
            </Button>
            <CartBadge />
            <NotificationBell />
            <ThemeToggle />
            <Button variant="ghost" size="icon" asChild aria-label="حساب کاربری">
              <Link href={isAuthenticated ? (isAdmin ? "/admin" : "/account") : "/login"}>
                <User className="size-5" />
              </Link>
            </Button>
          </div>
        </div>

        {/* Category nav (desktop) — single button with dropdown */}
        <nav className="hidden border-t border-border/60 bg-card lg:block">
          <div className="container-site flex h-11 items-center gap-4 text-sm">
            <CategoryNavMenu />
            <div className="mr-auto flex items-center gap-4">
              <CategoryLink href="/products?hasDiscount=true">تخفیف‌دارها</CategoryLink>
              <CategoryLink href="/products?isFeatured=true">پرفروش‌ها</CategoryLink>
              <CategoryLink href="/brands">برندها</CategoryLink>
              <CategoryLink href="/blog">وبلاگ</CategoryLink>
            </div>
          </div>
        </nav>
      </header>

      {/* Mobile search drawer */}
      <Drawer open={searchDrawerOpen} onOpenChange={setSearchDrawerOpen}>
        <DrawerContent className="max-h-[80vh]">
          <DrawerHeader className="pb-2">
            <DrawerTitle className="text-right">جست‌وجو</DrawerTitle>
          </DrawerHeader>
          <div className="px-4 pb-6">
            <form onSubmit={onSearch} className="space-y-3">
              <div className="relative">
                <Search className="pointer-events-none absolute right-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="جست‌وجو در محصولات..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pr-9"
                  autoFocus
                />
              </div>
              <Button type="submit" className="w-full" disabled={!searchQuery.trim()}>
                <Search className="size-4" />
                جست‌وجو
              </Button>
            </form>
          </div>
        </DrawerContent>
      </Drawer>

      {/* Mobile bottom nav */}
      <MobileBottomNav />
    </>
  );
}

/* ───────── Mobile bottom navigation ───────── */

function MobileBottomNav() {
  const { isAuthenticated, user } = useAuth();
  const isAdmin = isAuthenticated && ["ADMIN", "EDITOR", "SUPPORT"].includes(user?.role ?? "");

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 flex items-center justify-around border-t border-border bg-background/95 backdrop-blur-md lg:hidden">
      <BottomNavItem href="/" icon={<Home className="size-5" />} label="خانه" />
      <BottomNavItem href="/categories" icon={<Grid className="size-5" />} label="دسته‌ها" />
      <BottomNavItem href="/cart" icon={<ShoppingCart className="size-5" />} label="سبد" />
      {isAuthenticated ? (
        <BottomNavItem href={isAdmin ? "/admin" : "/account"} icon={<User className="size-5" />} label="حساب" />
      ) : (
        <BottomNavItem href="/login" icon={<User className="size-5" />} label="ورود" />
      )}
    </nav>
  );
}

function BottomNavItem({ href, icon, label }: { href: string; icon: React.ReactNode; label: string }) {
  return (
    <Link
      href={href}
      className="flex flex-1 flex-col items-center gap-0.5 py-2 text-muted-foreground transition-colors hover:text-primary"
    >
      {icon}
      <span className="text-[10px] font-medium">{label}</span>
    </Link>
  );
}

function CategoryLink({
  href,
  children,
}: {
  href: string;
  children: React.ReactNode;
}) {
  return (
    <Link
      href={href}
      className="whitespace-nowrap text-muted-foreground transition-colors hover:text-primary"
    >
      {children}
    </Link>
  );
}

function MobileLink({
  href,
  children,
  onClick,
}: {
  href: string;
  children: React.ReactNode;
  onClick?: () => void;
}) {
  return (
    <Link
      href={href}
      onClick={onClick}
      className="rounded-lg px-3 py-2.5 text-foreground transition-colors hover:bg-accent hover:text-accent-foreground"
    >
      {children}
    </Link>
  );
}

"use client";

import * as React from "react";

import { AuthGuard } from "@/components/common/auth-guard";
import { AccountSidebar } from "@/features/account/components/account-sidebar";

export default function AccountLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <AuthGuard>
      <div className="container-site py-6">
        {/* Mobile: full width; Desktop: grid with sidebar */}
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-4">
          <AccountSidebar />
          <div className="lg:col-span-3">{children}</div>
        </div>
      </div>
    </AuthGuard>
  );
}

# اشکالات بک‌اند + پرامپت Claude

## پرامپت برای ارسال به Claude

کد زیر را کپی کرده و به Claude بفرستید:

---

```
من یک پروژه بک‌اند Express + Prisma دارم که API یک فروشگاه اینترنتی فارسی را ارائه می‌دهد. فرانت‌اند Next.js من با این بک‌اند کار می‌کند اما چند مشکل در پاسخ‌های API وجود دارد که باید اصلاح شود. لطفاً هر مورد را بررسی و اصلاح کنید.

## ۱. Brand و Category بدون URL تصویر
**مسیرهای تأثیرگذار:** `GET /brands`, `GET /brands/:id`, `GET /categories/tree`, `GET /categories/:id`

**مشکل:** بک‌اند فقط `logoId` (برای Brand) و `imageId` (برای Category) برمی‌گرداند، نه URL آماده. فرانت نمی‌تواند تصویر را نمایش دهد.

**راه‌حل:** در service بک‌اند، هنگام serialization، `logoUrl` و `imageUrl` را از روی `logoId`/`imageId` و جدول Media پر کنید:

```typescript
// در brand.service.ts
const brands = await prisma.brand.findMany({
  include: { logo: true },
});
return brands.map(b => ({
  ...b,
  logoUrl: b.logo?.url ?? null,
}));
```

همین کار را برای Category با `imageId` و فیلد `image` انجام دهید.

## ۲. WishlistItem.product ساختار ناقص
**مسیر تأثیرگذار:** `GET /wishlist`

**مشکل:** `product` در آیتم‌های wishlist فیلدهای محدود دارد (`image` خالی، `variants` وجود ندارد، `brand` ناقص).

**راه‌حل:** `WishlistItem.product` را مثل `GET /products/:slug` کامل برگردانید (حداقل `variants` و `images` را include کنید):

```typescript
const wishlist = await prisma.wishlistItem.findMany({
  where: { userId },
  include: {
    product: {
      include: {
        brand: true,
        images: { include: { media: true }, orderBy: { order: 'asc' } },
        variants: true,
      },
    },
  },
});
```

## ۳. Comment بدون user object
**مسیر تأثیرگذار:** `GET /comments/product/:productId`

**مشکل:** نظرات شامل object کاربر (`fullName`, `avatarUrl`) نیستند — فقط `userId` برمی‌گردد.

**راه‌حل:** در `comment.service.ts`، هنگام fetch نظرات، `user` را include کنید:

```typescript
const comments = await prisma.comment.findMany({
  where: { productId, status: "APPROVED", parentId: null },
  include: {
    user: { select: { id: true, fullName: true, avatarUrl: true } },
    replies: {
      include: { user: { select: { id: true, fullName: true, avatarUrl: true } } },
    },
  },
});
```

## ۴. sitemap.xml فقط URL خانه را برمی‌گرداند
**مسیر تأثیرگذار:** `GET /sitemap.xml`

**مشکل:** با وجود وجود محصول/دسته/برند، sitemap فقط URL خانه را برمی‌گرداند.

**راه‌حل:** در `src/services/seo/sitemap.service.ts`، تابع `buildUrl` و تابع اصلی sitemap را بررسی کنید که محصولات منتشرشده + دسته‌های فعال + برندهای فعال را اضافه می‌کند.

## ۵. ProductImage ساختار تودرتو
**مسیر تأثیرگذار:** `GET /products`, `GET /products/:slug`

**مشکل:** تصاویر محصول به این شکل برمی‌گردند:
```json
{ "mediaId": "...", "media": { "url": "...", "alt": "..." } }
```
نه flat:
```json
{ "mediaId": "...", "url": "...", "alt": "..." }
```

**راه‌حل:** فیلدهای `url` و `alt` را flat هم روی خود `ProductImage` قرار دهید:

```typescript
// در serialization
const images = product.images.map(img => ({
  ...img,
  url: img.media?.url ?? null,
  alt: img.media?.alt ?? null,
}));
```

## ۶. ProductVariant.attributeValues ساختار junction
**مسیر تأثیرگذار:** `GET /products/:slug`

**مشکل:** به‌جای آرایه ساده `AttributeValue[]`، junction rows برمی‌گردد.

**راه‌حل:** attributeValues را flat کنید:

```typescript
const variants = product.variants.map(v => ({
  ...v,
  attributeValues: v.attributeValues.map(av => ({
    id: av.attributeValue.id,
    attributeId: av.attributeValue.attributeId,
    value: av.attributeValue.value,
    colorHex: av.attributeValue.colorHex,
    order: av.attributeValue.order,
    attribute: av.attributeValue.attribute,
  })),
}));
```

## ۷. Product.categories ساختار junction
**مسیر تأثیرگذار:** `GET /products`, `GET /products/:slug`

**مشکل:** به‌جای `Category[]`، junction rows برمی‌گردد.

**راه‌حل:** categories را flat کنید:

```typescript
const categories = product.categories.map(pc => pc.category);
```

## ۸. `GET /cart` شکل پاسخ
**مسیر تأثیرگذار:** `GET /cart`

**مشکل:** api.md می‌گوید پاسخ `GET /cart` هم `{ cart, guestToken? }` است، اما در عمل فقط `Cart` برمی‌گرداند.

**راه‌حل:** در `cart.controller.ts`، پاسخ `GET /cart` را هم مثل سایر مسیرها به `{ cart, guestToken? }` تغییر دهید:

```typescript
// GET /
res.json({
  success: true,
  message: 'موفقیت‌آمیز بود',
  data: { cart, guestToken: guestToken ?? undefined },
});
```

## ۹. ADMIN ایجاد کاربر (add admin)
**مشکل:** فرانت‌اند نیاز دارد که ادمین بتواند کاربر جدید (با نقش مدیر/پشتیبانی/ویرایشگر) ایجاد کند. فعلاً فقط `POST /auth/register` وجود دارد که فقط CUSTOMER می‌سازد.

**راه‌حل:** یک endpoint جدید اضافه کنید:

```
POST /api/v1/users/admin
Auth: ADMIN
Body: { fullName, identifier, password, role: "EDITOR" | "SUPPORT" | "ADMIN" }
```

این endpoint باید:
- کاربر را با نقش مشخص‌شده ایجاد کند (بدون نیاز به OTP)
- رمز عبور را hash کند
- ایمیل/موبایل را تاییدشده علامت بزند
- در `users.admin.controller.ts` و `users.admin.routes.ts` اضافه شود

## ۱۰. Stories (استوری) — endpoint جدید
**مشکل:** فرانت‌اند نیاز به یک بخش استوری (مثل اینستاگرام) در صفحه اصلی دارد.

**راه‌حل:** یک ماژول جدید به نام Stories اضافه کنید:

```
GET /api/v1/stories
Auth: ندارد (عمومی)
Response: [{ id, title, imageUrl, link, expiresAt }]
```

مدل Prisma:
```prisma
model Story {
  id          String   @id @default(cuid())
  title       String
  mediaId     String
  imageUrl    String   // computed from media
  link        String?
  isActive    Boolean  @default(true)
  createdAt   DateTime @default(now())
  expiresAt   DateTime
  media       Media    @relation(fields: [mediaId], references: [id])
}
```

## ۱۱. Media — تگ‌گذاری و جست‌وجو
**مسیر تأثیرگذار:** `GET /media`, `POST /media`

**مشکل:** کتابخانه رسانه نیاز به تگ‌گذاری دارد تا بتوان سریع فایل‌ها را پیدا کرد. همچنین جست‌وجو با نام فایل.

**راه‌حل:**
1. فیلد `tags` (رشته‌ای با کاما جدا) به مدل Media اضافه کنید
2. فیلد `alt` قبلاً وجود دارد — آن را در آپلود قابل تنظیم کنید
3. `GET /media` را با پارامتر `search` و `tag` فیلترپذیر کنید:

```
GET /api/v1/media?search=keyword&tag=product&page=1&limit=20
```

## ۱۲. Blog — ماژول وبلاگ
**مشکل:** فرانت‌اند نیاز به ماژول وبلاگ دارد (فعلاً placeholder استفاده می‌کند).

**راه‌حل:** یک ماژول کامل Blog اضافه کنید:

```
GET /api/v1/blog/posts?page=&limit=&category=&search=
GET /api/v1/blog/posts/:slug
POST /api/v1/blog/posts (ADMIN/EDITOR)
PUT /api/v1/blog/posts/:id (ADMIN/EDITOR)
DELETE /api/v1/blog/posts/:id (ADMIN/EDITOR)
GET /api/v1/blog/categories
```

مدل Prisma:
```prisma
model BlogPost {
  id          String   @id @default(cuid())
  title       String
  slug        String   @unique
  excerpt     String
  content     String   // HTML
  categoryId  String?
  coverMediaId String?
  status      PostStatus @default(DRAFT)
  metaTitle   String?
  metaDescription String?
  publishedAt DateTime?
  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt
  category    BlogCategory? @relation(fields: [categoryId], references: [id])
  cover       Media?   @relation(fields: [coverMediaId], references: [id])
}

model BlogCategory {
  id    String @id @default(cuid())
  name  String
  slug  String @unique
  posts BlogPost[]
}

enum PostStatus {
  DRAFT
  PUBLISHED
  ARCHIVED
}
```

---

لطفاً هر مورد را در فایل مربوطه اصلاح کنید و تغییرات را به‌صورت git diff ارائه دهید.
```

---

## خلاصه اشکالات (برای مرجع)

| # | اولویت | توضیح | وضعیت فرانت |
|---|--------|-------|-------------|
| ۱ | 🔴 بالا | Brand/Category بدون URL تصویر | fallback حرف اول |
| ۲ | 🔴 بالا | WishlistItem.product ناقص | لینک به صفحه محصول |
| ۳ | 🔴 بالا | Comment بدون user object | fallback «کاربر» |
| ۴ | 🔴 بالا | sitemap فقط URL خانه | sitemap.ts بومی Next.js |
| ۵ | 🟡 متوسط | ProductImage تودرتو | helper |
| ۶ | 🟡 متوسط | attributeValues junction | helper |
| ۷ | 🟡 متوسط | categories junction | helper |
| ۸ | 🟡 متوسط | GET /cart شکل پاسخ | فقط روی POST |
| ۹ | 🔴 بالا | ADMIN ایجاد کاربر جدید | — |
| ۱۰ | 🟡 متوسط | Stories endpoint | placeholder در فرانت |
| ۱۱ | 🟡 متوسط | Media tags + search | — |
| ۱۲ | 🔴 بالا | Blog module | placeholder در فرانت |

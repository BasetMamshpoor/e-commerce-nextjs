"use client";

import * as React from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  LayoutDashboard,
  User,
  ShieldCheck,
  Wallet,
  MapPin,
  Package,
  Ticket,
  Bell,
  LogOut,
  ChevronLeft,
  Menu,
  X,
} from "lucide-react";

import { cn } from "@/lib/utils";
import { useAuth } from "@/providers/auth-context";
import { useLogout } from "@/features/auth/hooks";
import { useUnreadNotificationsCount } from "@/features/notifications/hooks";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { ScrollArea } from "@/components/ui/scroll-area";
import { toPersianDigits } from "@/utils/format";

const NAV_ITEMS = [
  { href: "/account", label: "داشبورد", icon: LayoutDashboard },
  { href: "/account/profile", label: "پروفایل", icon: User },
  { href: "/account/security", label: "امنیت", icon: ShieldCheck },
  { href: "/account/wallet", label: "کیف پول", icon: Wallet },
  { href: "/account/addresses", label: "آدرس‌ها", icon: MapPin },
  { href: "/account/orders", label: "سفارش‌ها", icon: Package },
  { href: "/account/tickets", label: "تیکت‌ها", icon: Ticket },
  { href: "/account/notifications", label: "نوتیفیکیشن‌ها", icon: Bell },
] as const;

export function AccountSidebar() {
  const pathname = usePathname();
  const { user } = useAuth();
  const { data: unreadData } = useUnreadNotificationsCount();
  const unreadCount = unreadData?.count ?? 0;
  const logout = useLogout();
  const [mobileOpen, setMobileOpen] = React.useState(false);

  const isActive = (href: string) =>
    href === "/account" ? pathname === "/account" : pathname.startsWith(href);

  const initials = (user?.fullName ?? "؟")
    .split(" ")
    .map((p) => p.charAt(0))
    .slice(0, 2)
    .join("");

  const sidebarContent = (
    <div className="space-y-4">
      {/* User card */}
      <div className="flex items-center gap-3 rounded-xl border border-border bg-muted/30 p-3">
        <Avatar className="size-11 border border-border">
          <AvatarImage src={user?.avatarUrl ?? undefined} alt={user?.fullName} />
          <AvatarFallback className="bg-primary/10 text-sm font-bold text-primary">
            {initials}
          </AvatarFallback>
        </Avatar>
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-medium text-foreground">
            {user?.fullName ?? "کاربر"}
          </p>
          <p className="truncate text-xs text-muted-foreground" dir="ltr">
            {user?.email ?? user?.phone ?? ""}
          </p>
        </div>
      </div>

      {/* Nav */}
      <nav className="space-y-1">
        {NAV_ITEMS.map((item) => {
          const active = isActive(item.href);
          const Icon = item.icon;
          const showBadge = item.href === "/account/notifications" && unreadCount > 0;
          return (
            <Link
              key={item.href}
              href={item.href}
              onClick={() => setMobileOpen(false)}
              className={cn(
                "flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-colors",
                active
                  ? "bg-primary text-primary-foreground shadow-sm"
                  : "text-muted-foreground hover:bg-accent hover:text-accent-foreground",
              )}
            >
              <Icon className="size-4 shrink-0" />
              <span className="flex-1">{item.label}</span>
              {showBadge && (
                <span className="flex min-w-5 items-center justify-center rounded-full bg-primary-foreground px-1 text-[10px] font-bold text-primary nums-fa">
                  {toPersianDigits(unreadCount > 99 ? "۹۹+" : unreadCount)}
                </span>
              )}
              {active && <ChevronLeft className="size-4" />}
            </Link>
          );
        })}
      </nav>

      {/* Logout */}
      <Button
        variant="outline"
        className="w-full justify-start text-destructive hover:text-destructive"
        onClick={() => logout.mutate()}
        disabled={logout.isPending}
      >
        <LogOut className="size-4" />
        خروج از حساب
      </Button>
    </div>
  );

  return (
    <>
      {/* Desktop sidebar */}
      <aside className="hidden lg:block">
        <div className="sticky top-32 rounded-xl border border-border bg-card p-4">
          {sidebarContent}
        </div>
      </aside>

      {/* Mobile menu trigger */}
      <div className="lg:hidden">
        <Button
          variant="outline"
          className="w-full justify-between"
          onClick={() => setMobileOpen(true)}
        >
          <span className="flex items-center gap-2">
            <Menu className="size-4" />
            منوی حساب کاربری
          </span>
          <ChevronLeft className="size-4" />
        </Button>
      </div>

      {/* Mobile sidebar — full screen */}
      <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
        <SheetContent side="right" className="w-full p-0 sm:w-96">
          <SheetHeader className="flex flex-row items-center justify-between border-b border-border p-4">
            <SheetTitle className="text-right">حساب کاربری</SheetTitle>
            <Button variant="ghost" size="icon" className="size-8" onClick={() => setMobileOpen(false)}>
              <X className="size-4" />
            </Button>
          </SheetHeader>
          <ScrollArea className="h-[calc(100vh-4rem)] p-4">
            {sidebarContent}
          </ScrollArea>
        </SheetContent>
      </Sheet>
    </>
  );
}

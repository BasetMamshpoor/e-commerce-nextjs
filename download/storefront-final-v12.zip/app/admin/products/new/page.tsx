"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import { ArrowRight, Loader2 } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { productsService, brandsService, categoriesService } from "@/services";
import type { Brand, Category, ProductStatus } from "@/types/domain";

const STATUS_OPTIONS: { value: ProductStatus; label: string }[] = [
  { value: "DRAFT", label: "پیش‌نویس" },
  { value: "PUBLISHED", label: "منتشر شده" },
  { value: "ARCHIVED", label: "آرشیو شده" },
];

export default function AdminProductNewPage() {
  const router = useRouter();
  const [brands, setBrands] = React.useState<Brand[]>([]);
  const [categories, setCategories] = React.useState<Category[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [saving, setSaving] = React.useState(false);

  const [form, setForm] = React.useState({
    name: "",
    brandId: "",
    shortDescription: "",
    description: "",
    status: "DRAFT" as ProductStatus,
    isFeatured: false,
    categoryIds: [] as string[],
    variants: [{ sku: "", price: 0, stock: 0, isDefault: true, attributeValueIds: [] as string[] }],
  });

  React.useEffect(() => {
    Promise.all([
      brandsService.list({ includeInactive: true }),
      categoriesService.list(),
    ]).then(([b, c]) => {
      setBrands(b);
      setCategories(c);
    }).finally(() => setLoading(false));
  }, []);

  const onSubmit = async () => {
    if (!form.name.trim()) {
      toast.error("نام محصول الزامی است");
      return;
    }
    if (form.variants[0].price <= 0) {
      toast.error("قیمت تنوع الزامی است");
      return;
    }
    setSaving(true);
    try {
      const body = {
        name: form.name,
        brandId: form.brandId || undefined,
        shortDescription: form.shortDescription || undefined,
        description: form.description || undefined,
        status: form.status,
        isFeatured: form.isFeatured,
        categoryIds: form.categoryIds,
        variants: form.variants.map((v) => ({
          sku: v.sku || `SKU-${Date.now()}`,
          price: Number(v.price),
          stock: Number(v.stock),
          isDefault: v.isDefault,
          attributeValueIds: v.attributeValueIds,
        })),
        images: [],
      };
      const product = await productsService.create(body);
      toast.success("محصول ایجاد شد");
      router.push(`/admin/products/${product.id}`);
    } catch (err) {
      toast.error("ایجاد محصول ناموفق بود");
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-96 w-full rounded-xl" />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <Button asChild variant="ghost" size="icon">
          <button onClick={() => router.back()}>
            <ArrowRight className="size-5" />
          </button>
        </Button>
        <h1 className="text-xl font-bold text-foreground sm:text-2xl">محصول جدید</h1>
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-base">اطلاعات اصلی</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>نام محصول *</Label>
              <Input
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                placeholder="مثال: کفش اسنیکر نایک Air Max"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>برند</Label>
                <Select value={form.brandId} onValueChange={(v) => setForm({ ...form, brandId: v })}>
                  <SelectTrigger><SelectValue placeholder="انتخاب برند" /></SelectTrigger>
                  <SelectContent>
                    {brands.map((b) => (
                      <SelectItem key={b.id} value={b.id}>{b.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>وضعیت</Label>
                <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v as ProductStatus })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {STATUS_OPTIONS.map((o) => (
                      <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label>توضیح کوتاه</Label>
              <Input
                value={form.shortDescription}
                onChange={(e) => setForm({ ...form, shortDescription: e.target.value })}
                placeholder="توضیح یک‌خطی محصول"
              />
            </div>

            <div className="space-y-2">
              <Label>توضیحات کامل (HTML)</Label>
              <Textarea
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
                rows={6}
                placeholder="<p>توضیحات محصول...</p>"
              />
            </div>

            <label className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={form.isFeatured}
                onChange={(e) => setForm({ ...form, isFeatured: e.target.checked })}
                className="size-4 rounded"
              />
              <span className="text-sm">محصول ویژه</span>
            </label>

            <div className="space-y-2">
              <Label>دسته‌بندی‌ها</Label>
              <div className="grid grid-cols-2 gap-2 rounded-lg border border-border p-3 sm:grid-cols-3">
                {categories.map((c) => (
                  <label key={c.id} className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={form.categoryIds.includes(c.id)}
                      onChange={(e) => {
                        if (e.target.checked) {
                          setForm({ ...form, categoryIds: [...form.categoryIds, c.id] });
                        } else {
                          setForm({ ...form, categoryIds: form.categoryIds.filter((id) => id !== c.id) });
                        }
                      }}
                      className="size-4 rounded"
                    />
                    <span className="text-sm">{c.name}</span>
                  </label>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">تنوع پیش‌فرض</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="space-y-2">
                <Label>SKU</Label>
                <Input
                  value={form.variants[0].sku}
                  onChange={(e) => {
                    const variants = [...form.variants];
                    variants[0] = { ...variants[0], sku: e.target.value };
                    setForm({ ...form, variants });
                  }}
                  placeholder="مثال: NIKE-AIRMAX-RED-41"
                  dir="ltr"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2">
                  <Label>قیمت (تومان) *</Label>
                  <Input
                    type="number"
                    value={form.variants[0].price}
                    onChange={(e) => {
                      const variants = [...form.variants];
                      variants[0] = { ...variants[0], price: Number(e.target.value) };
                      setForm({ ...form, variants });
                    }}
                    dir="ltr"
                  />
                </div>
                <div className="space-y-2">
                  <Label>موجودی</Label>
                  <Input
                    type="number"
                    value={form.variants[0].stock}
                    onChange={(e) => {
                      const variants = [...form.variants];
                      variants[0] = { ...variants[0], stock: Number(e.target.value) };
                      setForm({ ...form, variants });
                    }}
                    dir="ltr"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="flex gap-2">
            <Button variant="outline" className="flex-1" onClick={() => router.back()}>
              انصراف
            </Button>
            <Button className="flex-1" onClick={onSubmit} disabled={saving}>
              {saving ? <Loader2 className="size-4 animate-spin" /> : null}
              ایجاد محصول
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}

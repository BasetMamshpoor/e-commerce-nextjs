"use client";

import * as React from "react";
import Link from "next/link";
import {
  Bell,
  CheckCheck,
  Trash2,
  Package,
  MessageSquare,
  Ticket,
  Wallet,
  AlertCircle,
  Megaphone,
  Loader2,
} from "lucide-react";

import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Breadcrumb } from "@/components/common/breadcrumb";
import { EmptyState } from "@/components/common/empty-state";
import {
  useNotifications,
  useMarkNotificationRead,
  useMarkAllNotificationsRead,
  useDeleteNotification,
  useUnreadNotificationsCount,
} from "@/features/notifications/hooks";
import { formatRelativeFa, formatDateTimeFa, toPersianDigits } from "@/utils/format";
import type { NotificationType } from "@/types/domain";
import { cn } from "@/lib/utils";

const TYPE_CONFIG: Record<NotificationType, { icon: React.ReactNode; color: string; bg: string }> = {
  ORDER: { icon: <Package className="size-4" />, color: "text-blue-600", bg: "bg-blue-50 dark:bg-blue-950/30" },
  SYSTEM: { icon: <AlertCircle className="size-4" />, color: "text-gray-600", bg: "bg-gray-50 dark:bg-gray-950/30" },
  TICKET: { icon: <Ticket className="size-4" />, color: "text-amber-600", bg: "bg-amber-50 dark:bg-amber-950/30" },
  PROMOTION: { icon: <Megaphone className="size-4" />, color: "text-primary", bg: "bg-primary/10" },
  WALLET: { icon: <Wallet className="size-4" />, color: "text-green-600", bg: "bg-green-50 dark:bg-green-950/30" },
  COMMENT: { icon: <MessageSquare className="size-4" />, color: "text-purple-600", bg: "bg-purple-50 dark:bg-purple-950/30" },
};

export default function NotificationsPage() {
  const { data, isLoading } = useNotifications({ limit: 50 });
  const markAll = useMarkAllNotificationsRead();
  const { data: unreadData } = useUnreadNotificationsCount();
  const unreadCount = unreadData?.count ?? 0;
  const notifications = data?.items ?? [];

  return (
    <div className="space-y-6">
      <Breadcrumb
        items={[
          { name: "خانه", url: "/" },
          { name: "حساب کاربری", url: "/account" },
          { name: "نوتیفیکیشن‌ها", url: "/account/notifications" },
        ]}
      />

      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-foreground sm:text-2xl">
            نوتیفیکیشن‌ها
            {unreadCount > 0 && (
              <span className="mr-2 rounded-full bg-primary px-2 py-0.5 text-xs font-medium text-primary-foreground nums-fa">
                {toPersianDigits(unreadCount)} جدید
              </span>
            )}
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">اعلان‌های سفارش، کیف پول و تخفیف‌ها</p>
        </div>
        {unreadCount > 0 && (
          <Button
            variant="outline"
            size="sm"
            onClick={() => markAll.mutate()}
            disabled={markAll.isPending}
          >
            {markAll.isPending ? (
              <Loader2 className="size-4 animate-spin" />
            ) : (
              <CheckCheck className="size-4" />
            )}
            خواندن همه
          </Button>
        )}
      </div>

      {isLoading ? (
        <div className="space-y-2">
          {Array.from({ length: 5 }).map((_, i) => (
            <Skeleton key={i} className="h-20 w-full rounded-xl" />
          ))}
        </div>
      ) : notifications.length === 0 ? (
        <EmptyState
          icon={<Bell className="size-16" />}
          title="نوتیفیکیشنی وجود ندارد"
          description="اعلان‌های مربوط به سفارش‌ها، کیف پول و تخفیف‌ها در این صفحه نمایش داده می‌شوند."
          className="border border-dashed border-border rounded-xl"
        />
      ) : (
        <div className="space-y-2">
          {notifications.map((n) => (
            <NotificationItem key={n.id} notification={n} />
          ))}
        </div>
      )}
    </div>
  );
}

function NotificationItem({
  notification,
}: {
  notification: import("@/types/domain").AppNotification;
}) {
  const markRead = useMarkNotificationRead();
  const del = useDeleteNotification();
  const cfg = TYPE_CONFIG[notification.type] ?? TYPE_CONFIG.SYSTEM;

  const content = (
    <Card
      className={cn(
        "border-border/60 transition-colors hover:border-primary/30",
        !notification.isRead && "border-primary/30 bg-primary/5",
      )}
    >
      <CardContent className="flex items-start gap-3 p-3 sm:p-4">
        <div className={cn("flex size-9 shrink-0 items-center justify-center rounded-lg", cfg.bg, cfg.color)}>
          {cfg.icon}
        </div>
        <div className="min-w-0 flex-1">
          <div className="flex items-start justify-between gap-2">
            <p className="text-sm font-medium text-foreground">{notification.title}</p>
            {!notification.isRead && (
              <span className="mt-1.5 size-2 shrink-0 rounded-full bg-primary" />
            )}
          </div>
          <p className="mt-0.5 text-sm text-muted-foreground">{notification.message}</p>
          <p className="mt-1.5 text-xs text-muted-foreground">
            {formatRelativeFa(notification.createdAt)}
            <span className="mx-2">•</span>
            {formatDateTimeFa(notification.createdAt)}
          </p>
        </div>
        <div className="flex shrink-0 flex-col gap-1">
          {!notification.isRead && (
            <Button
              variant="ghost"
              size="icon"
              className="size-8 text-muted-foreground"
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                markRead.mutate(notification.id);
              }}
              aria-label="خواندن"
            >
              <CheckCheck className="size-4" />
            </Button>
          )}
          <Button
            variant="ghost"
            size="icon"
            className="size-8 text-muted-foreground hover:text-destructive"
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              del.mutate(notification.id);
            }}
            aria-label="حذف"
          >
            <Trash2 className="size-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );

  if (notification.link) {
    return <Link href={notification.link}>{content}</Link>;
  }
  return content;
}

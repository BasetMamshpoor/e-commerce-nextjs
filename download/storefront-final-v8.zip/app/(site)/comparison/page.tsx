"use client";

import * as React from "react";
import Link from "next/link";
import Image from "next/image";
import {
  Scale,
  X,
  ShoppingBag,
  ArrowLeft,
  Check,
  Minus,
  Plus,
  Trash2,
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Separator } from "@/components/ui/separator";
import { Breadcrumb } from "@/components/common/breadcrumb";
import { EmptyState } from "@/components/common/empty-state";
import {
  useComparison,
  useRemoveFromComparison,
  useClearComparison,
} from "@/features/comparison/hooks";
import { AddToCartButton } from "@/components/site/add-to-cart-button";
import {
  formatToman,
  formatPrice,
  toPersianDigits,
} from "@/utils/format";
import type { ComparisonItem, Product } from "@/types/domain";
import { getProductImageUrl } from "@/types/domain";
import { cn } from "@/lib/utils";

export default function ComparisonPage() {
  const { data: comparison, isLoading } = useComparison();
  const clear = useClearComparison();
  const items = comparison?.items ?? [];

  return (
    <div className="container-site py-6">
      <Breadcrumb
        items={[
          { name: "خانه", url: "/" },
          { name: "مقایسه", url: "/comparison" },
        ]}
      />

      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-xl font-bold text-foreground sm:text-2xl">
          مقایسه محصولات
          {items.length > 0 && (
            <span className="mr-2 text-sm font-normal text-muted-foreground">
              ({toPersianDigits(items.length)} از {toPersianDigits(4)} محصول)
            </span>
          )}
        </h1>
        {items.length > 0 && (
          <Button
            variant="outline"
            size="sm"
            className="text-muted-foreground hover:text-destructive"
            onClick={() => clear.mutate()}
            disabled={clear.isPending}
          >
            <X className="size-4" />
            خالی کردن
          </Button>
        )}
      </div>

      {isLoading ? (
        <Skeleton className="h-96 w-full rounded-xl" />
      ) : items.length === 0 ? (
        <EmptyState
          icon={<Scale className="size-16" />}
          title="لیست مقایسه شما خالی است"
          description="حداکثر ۴ محصول را برای مقایسه‌ی ویژگی‌ها به این لیست اضافه کنید. از صفحه جزئیات محصول می‌توانید مقایسه را شروع کنید."
          action={
            <Button asChild>
              <Link href="/products">
                مشاهده محصولات
                <ArrowLeft className="size-4" />
              </Link>
            </Button>
          }
          className="border border-dashed border-border rounded-xl"
        />
      ) : (
        <ComparisonView items={items} />
      )}
    </div>
  );
}

function ComparisonView({ items }: { items: ComparisonItem[] }) {
  const remove = useRemoveFromComparison();

  return (
    <div className="space-y-4">
      {/* Product cards row */}
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {items.map((item) => (
          <ComparisonProductCard
            key={item.id}
            item={item}
            onRemove={() => remove.mutate(item.productId)}
            removing={remove.isPending}
          />
        ))}
        {items.length < 4 && (
          <Link
            href="/products"
            className="flex min-h-[200px] flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed border-border text-muted-foreground transition-colors hover:border-primary/40 hover:text-primary"
          >
            <Plus className="size-8" />
            <span className="text-sm">افزودن محصول</span>
          </Link>
        )}
      </div>

      {/* Comparison table */}
      <Card className="overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[640px]">
            <thead>
              <tr className="border-b border-border bg-muted/30">
                <th className="w-32 p-3 text-right text-xs font-medium text-muted-foreground">ویژگی</th>
                {items.map((item) => (
                  <th key={item.id} className="p-3 text-center text-xs font-medium text-muted-foreground">
                    {item.product.name}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              <ComparisonRow label="قیمت" items={items} render={(p) =>
                p.isInStock ? <span className="nums-fa">{formatToman(p.minPrice)}</span> : <span className="text-muted-foreground">—</span>
              } />
              <ComparisonRow label="وضعیت موجودی" items={items} render={(p) =>
                p.isInStock ? (
                  <span className="inline-flex items-center gap-1 text-green-600"><Check className="size-4" /> موجود</span>
                ) : (
                  <span className="inline-flex items-center gap-1 text-red-600"><Minus className="size-4" /> ناموجود</span>
                )
              } />
              <ComparisonRow label="تخفیف" items={items} render={(p) =>
                p.hasActiveDiscount ? <span className="text-green-600">دارد</span> : <span className="text-muted-foreground">ندارد</span>
              } />
              <ComparisonRow label="برند" items={items} render={(p) =>
                p.brand ? <Link href={`/brands/${p.brand.slug}`} className="text-primary hover:underline">{p.brand.name}</Link> : <span className="text-muted-foreground">—</span>
              } />
              <ComparisonRow label="دسته‌بندی" items={items} render={(p) =>
                p.categories && p.categories.length > 0 ? <span>{p.categories.map((c) => c.name).join("، ")}</span> : <span className="text-muted-foreground">—</span>
              } />
              <ComparisonRow label="محصول ویژه" items={items} render={(p) =>
                p.isFeatured ? <span className="text-amber-600">بله</span> : <span className="text-muted-foreground">خیر</span>
              } />
              <ComparisonRow label="تنوع‌ها" items={items} render={(p) =>
                <span className="nums-fa">{toPersianDigits(p.variants?.length ?? 0)} تنوع</span>
              } />

              {/* Action row */}
              <tr className="border-t border-border">
                <td className="bg-muted/30 p-3 text-xs font-medium text-muted-foreground">عملیات</td>
                {items.map((item) => {
                  const singleVariant = item.product.variants && item.product.variants.length === 1
                    ? item.product.variants[0]
                    : null;
                  return (
                    <td key={item.id} className="p-3 text-center">
                      {singleVariant && singleVariant.stock > 0 ? (
                        <AddToCartButton variantId={singleVariant.id} size="sm" label="افزودن به سبد" />
                      ) : (
                        <Button asChild variant="outline" size="sm">
                          <Link href={`/products/${item.product.slug}`}>مشاهده</Link>
                        </Button>
                      )}
                    </td>
                  );
                })}
              </tr>
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}

function ComparisonProductCard({
  item,
  onRemove,
  removing,
}: {
  item: ComparisonItem;
  onRemove: () => void;
  removing: boolean;
}) {
  const p = item.product;
  const mainImage = p.images?.find((i) => i.isMain) ?? p.images?.[0];
  const imgUrl = mainImage ? getProductImageUrl(mainImage) : "";

  return (
    <Card className="group relative overflow-hidden border-border/40">
      <Button
        variant="ghost"
        size="icon"
        className="absolute left-2 top-2 z-10 size-7 text-muted-foreground hover:text-destructive"
        onClick={onRemove}
        disabled={removing}
      >
        <X className="size-4" />
      </Button>
      <Link href={`/products/${p.slug}`} className="block">
        <div className="relative aspect-square overflow-hidden bg-muted">
          {imgUrl ? (
            <Image
              src={imgUrl}
              alt={p.name}
              fill
              sizes="200px"
              className="object-cover transition-transform duration-300 group-hover:scale-105"
            />
          ) : (
            <div className="flex size-full items-center justify-center text-muted-foreground/30">
              <ShoppingBag className="size-8" />
            </div>
          )}
        </div>
      </Link>
      <div className="space-y-1 p-3">
        {p.brand && (
          <span className="text-[11px] text-muted-foreground">{p.brand.name}</span>
        )}
        <Link href={`/products/${p.slug}`} className="line-clamp-2 text-sm font-medium text-foreground hover:text-primary">
          {p.name}
        </Link>
        <p className="text-sm font-bold text-foreground nums-fa">
          {formatPrice(p.minPrice)}
          <span className="mr-1 text-xs font-normal text-muted-foreground">تومان</span>
        </p>
      </div>
    </Card>
  );
}

function ComparisonRow({
  label,
  items,
  render,
}: {
  label: string;
  items: ComparisonItem[];
  render: (product: Product) => React.ReactNode;
}) {
  return (
    <tr className="border-b border-border/40">
      <td className="bg-muted/30 p-3 text-xs font-medium text-muted-foreground">{label}</td>
      {items.map((item) => (
        <td key={item.id} className="p-3 text-center text-sm">
          {render(item.product)}
        </td>
      ))}
    </tr>
  );
}

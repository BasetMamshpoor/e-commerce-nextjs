"use client";

import * as React from "react";
import Link from "next/link";
import {
  Bell,
  CheckCheck,
  Trash2,
  Package,
  MessageSquare,
  Ticket,
  Wallet,
  AlertCircle,
  Megaphone,
  Loader2,
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Breadcrumb } from "@/components/common/breadcrumb";
import { EmptyState } from "@/components/common/empty-state";
import {
  useNotifications,
  useMarkNotificationRead,
  useMarkAllNotificationsRead,
  useDeleteNotification,
  useUnreadNotificationsCount,
} from "@/features/notifications/hooks";
import { formatRelativeFa, toPersianDigits } from "@/utils/format";
import type { NotificationType, AppNotification } from "@/types/domain";
import { cn } from "@/lib/utils";

const TYPE_ICON: Record<NotificationType, React.ReactNode> = {
  ORDER: <Package className="size-3.5" />,
  SYSTEM: <AlertCircle className="size-3.5" />,
  TICKET: <Ticket className="size-3.5" />,
  PROMOTION: <Megaphone className="size-3.5" />,
  WALLET: <Wallet className="size-3.5" />,
  COMMENT: <MessageSquare className="size-3.5" />,
};

const TYPE_COLOR: Record<NotificationType, string> = {
  ORDER: "text-blue-600 bg-blue-50 dark:bg-blue-950/30",
  SYSTEM: "text-gray-600 bg-gray-50 dark:bg-gray-950/30",
  TICKET: "text-amber-600 bg-amber-50 dark:bg-amber-950/30",
  PROMOTION: "text-primary bg-primary/10",
  WALLET: "text-green-600 bg-green-50 dark:bg-green-950/30",
  COMMENT: "text-purple-600 bg-purple-50 dark:bg-purple-950/30",
};

export default function NotificationsPage() {
  const { data, isLoading } = useNotifications({ limit: 50 });
  const markAll = useMarkAllNotificationsRead();
  const { data: unreadData } = useUnreadNotificationsCount();
  const unreadCount = unreadData?.count ?? 0;
  const notifications = data?.items ?? [];

  return (
    <div className="space-y-4">
      <Breadcrumb
        items={[
          { name: "خانه", url: "/" },
          { name: "حساب کاربری", url: "/account" },
          { name: "نوتیفیکیشن‌ها", url: "/account/notifications" },
        ]}
      />

      <div className="flex items-center justify-between">
        <h1 className="flex items-center gap-2 text-xl font-bold text-foreground sm:text-2xl">
          <Bell className="size-5 text-primary" />
          نوتیفیکیشن‌ها
          {unreadCount > 0 && (
            <span className="rounded-full bg-primary px-2 py-0.5 text-xs font-medium text-primary-foreground nums-fa">
              {toPersianDigits(unreadCount)}
            </span>
          )}
        </h1>
        {unreadCount > 0 && (
          <Button
            variant="outline"
            size="sm"
            onClick={() => markAll.mutate()}
            disabled={markAll.isPending}
          >
            {markAll.isPending ? <Loader2 className="size-4 animate-spin" /> : <CheckCheck className="size-4" />}
            خواندن همه
          </Button>
        )}
      </div>

      {isLoading ? (
        <div className="space-y-1.5">
          {Array.from({ length: 6 }).map((_, i) => (
            <Skeleton key={i} className="h-12 w-full rounded-lg" />
          ))}
        </div>
      ) : notifications.length === 0 ? (
        <EmptyState
          icon={<Bell className="size-16" />}
          title="نوتیفیکیشنی وجود ندارد"
          description="اعلان‌های سفارش، کیف پول و تخفیف‌ها اینجا نمایش داده می‌شوند."
          className="border border-dashed border-border rounded-xl"
        />
      ) : (
        <div className="space-y-1.5">
          {notifications.map((n) => (
            <NotificationRow key={n.id} notification={n} />
          ))}
        </div>
      )}
    </div>
  );
}

function NotificationRow({ notification: n }: { notification: AppNotification }) {
  const markRead = useMarkNotificationRead();
  const del = useDeleteNotification();
  const icon = TYPE_ICON[n.type] ?? TYPE_ICON.SYSTEM;
  const color = TYPE_COLOR[n.type] ?? TYPE_COLOR.SYSTEM;

  const row = (
    <div
      className={cn(
        "flex items-center gap-2.5 rounded-lg border px-3 py-2 transition-colors hover:bg-accent/40",
        n.isRead ? "border-border/40 bg-card" : "border-primary/20 bg-primary/5",
      )}
    >
      <div className={cn("flex size-7 shrink-0 items-center justify-center rounded-md", color)}>
        {icon}
      </div>
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-1.5">
          <p className="truncate text-sm font-medium text-foreground">{n.title}</p>
          {!n.isRead && <span className="size-1.5 shrink-0 rounded-full bg-primary" />}
        </div>
        <p className="truncate text-xs text-muted-foreground">{n.message}</p>
        <p className="text-[10px] text-muted-foreground/70">{formatRelativeFa(n.createdAt)}</p>
      </div>
      <div className="flex shrink-0 items-center gap-0.5">
        {!n.isRead && (
          <Button
            variant="ghost"
            size="icon"
            className="size-7 text-muted-foreground"
            onClick={(e) => { e.preventDefault(); e.stopPropagation(); markRead.mutate(n.id); }}
            aria-label="خواندن"
          >
            <CheckCheck className="size-3.5" />
          </Button>
        )}
        <Button
          variant="ghost"
          size="icon"
          className="size-7 text-muted-foreground hover:text-destructive"
          onClick={(e) => { e.preventDefault(); e.stopPropagation(); del.mutate(n.id); }}
          aria-label="حذف"
        >
          <Trash2 className="size-3.5" />
        </Button>
      </div>
    </div>
  );

  if (n.link) return <Link href={n.link}>{row}</Link>;
  return row;
}

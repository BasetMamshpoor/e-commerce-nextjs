"use client";

import * as React from "react";
import { useRouter } from "next/navigation";

import { AuthGuard } from "@/components/common/auth-guard";
import { AccountSidebar } from "@/features/account/components/account-sidebar";
import { useAuth } from "@/providers/auth-context";

export default function AccountLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const { user, isLoading } = useAuth();
  const router = useRouter();

  // Block admin/editor/support from /account — they should use /admin
  React.useEffect(() => {
    if (!isLoading && user && ["ADMIN", "EDITOR", "SUPPORT"].includes(user.role)) {
      router.replace("/admin");
    }
  }, [user, isLoading, router]);

  if (isLoading) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center">
        <div className="size-8 animate-spin rounded-full border-2 border-primary border-t-transparent" />
      </div>
    );
  }

  // Don't render account layout for admin users
  if (user && ["ADMIN", "EDITOR", "SUPPORT"].includes(user.role)) {
    return null;
  }

  return (
    <AuthGuard>
      <div className="container-site py-6">
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-4">
          <AccountSidebar />
          <div className="lg:col-span-3">{children}</div>
        </div>
      </div>
    </AuthGuard>
  );
}

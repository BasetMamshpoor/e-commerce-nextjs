"use client";

import * as React from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { ChevronLeft, ChevronRight, PackageSearch } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Breadcrumb } from "@/components/common/breadcrumb";
import { EmptyState } from "@/components/common/empty-state";
import { ProductCard, ProductCardSkeleton } from "@/components/site/product-card";
import { FilterSidebar, MobileFilterSheet } from "@/components/site/filter-sidebar";
import { SortBar } from "@/components/site/sort-bar";
import { useProductsInfinite } from "@/features/catalog/hooks/use-products-infinite";
import { useCategoryBySlug } from "@/features/catalog/hooks/use-categories";
import type { ProductListQuery, ProductSortOption } from "@/types/domain";
import { toPersianDigits } from "@/utils/format";
import { cn } from "@/lib/utils";

export default function ProductsPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [viewMode, setViewMode] = React.useState<"grid" | "list">("grid");
  const sentinelRef = React.useRef<HTMLDivElement>(null);

  const query: ProductListQuery = {
    categorySlug: searchParams.get("categorySlug") ?? undefined,
    brandIds: searchParams.get("brandIds") ?? undefined,
    attributeValueIds: searchParams.get("attributeValueIds") ?? undefined,
    minPrice: searchParams.get("minPrice") ? Number(searchParams.get("minPrice")) : undefined,
    maxPrice: searchParams.get("maxPrice") ? Number(searchParams.get("maxPrice")) : undefined,
    inStock: searchParams.get("inStock") === "true" || undefined,
    hasDiscount: searchParams.get("hasDiscount") === "true" || undefined,
    isFeatured: searchParams.get("isFeatured") === "true" || undefined,
    search: searchParams.get("search") ?? undefined,
    sort: (searchParams.get("sort") as ProductSortOption) ?? "newest",
  };

  const { data: category } = useCategoryBySlug(query.categorySlug);
  const {
    items,
    isLoading,
    isFetchingNextPage,
    hasNextPage,
    fetchNextPage,
    totalPages,
    total,
    currentPage,
    hasMoreInfinite,
    showPagination,
    INFINITE_PAGES,
  } = useProductsInfinite(query);

  // Infinite scroll observer
  React.useEffect(() => {
    const sentinel = sentinelRef.current;
    if (!sentinel || !hasMoreInfinite) return;

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && hasMoreInfinite) {
          fetchNextPage();
        }
      },
      { rootMargin: "200px" },
    );
    observer.observe(sentinel);
    return () => observer.disconnect();
  }, [hasMoreInfinite, fetchNextPage]);

  const updateSort = (sort: ProductSortOption) => {
    const params = new URLSearchParams(searchParams.toString());
    params.set("sort", sort);
    router.replace(`/products?${params.toString()}`, { scroll: false });
  };

  const goToPage = (page: number) => {
    const params = new URLSearchParams(searchParams.toString());
    params.set("page", String(page));
    router.replace(`/products?${params.toString()}`, { scroll: true });
  };

  const pageTitle = query.search
    ? `نتایج جست‌وجو: «${query.search}»`
    : category
      ? category.name
      : query.hasDiscount
        ? "محصولات تخفیف‌دار"
        : query.isFeatured
          ? "محصولات منتخب"
          : "همه محصولات";

  const breadcrumbItems = [
    { name: "خانه", url: "/" },
    { name: "محصولات", url: "/products" },
  ];
  if (category) {
    breadcrumbItems.push({ name: category.name, url: `/categories/${category.slug}` });
  }

  return (
    <div className="container-site py-6">
      <Breadcrumb items={breadcrumbItems} />

      <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-xl font-bold text-foreground sm:text-2xl">{pageTitle}</h1>
          {total > 0 && (
            <p className="mt-1 text-sm text-muted-foreground">
              {toPersianDigits(total)} کالا
            </p>
          )}
        </div>
        <div className="flex items-center gap-2">
          <MobileFilterSheet categorySlug={query.categorySlug} />
          <SortBar
            value={query.sort ?? "newest"}
            onChange={updateSort}
            viewMode={viewMode}
            onViewModeChange={setViewMode}
          />
        </div>
      </div>

      <div className="flex gap-6">
        {/* Sidebar (desktop) */}
        <aside className="hidden w-64 shrink-0 lg:block">
          <div className="sticky top-32 max-h-[calc(100vh-9rem)] overflow-y-auto pb-4">
            <FilterSidebar categorySlug={query.categorySlug} />
          </div>
        </aside>

        {/* Product grid */}
        <div className="min-w-0 flex-1">
          {isLoading ? (
            <ProductGridSkeleton count={12} variant={viewMode} />
          ) : items.length === 0 ? (
            <EmptyState
              icon={<PackageSearch className="size-16" />}
              title="محصولی یافت نشد"
              description="با فیلترهای فعلی محصولی پیدا نشد. فیلترها را تغییر دهید یا آنها را پاک کنید."
              action={
                <Button asChild variant="outline" size="sm">
                  <Link href="/products">حذف فیلترها</Link>
                </Button>
              }
              className="border border-dashed border-border rounded-xl"
            />
          ) : (
            <>
              <div
                className={cn(
                  viewMode === "grid"
                    ? "grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-4 lg:grid-cols-3 xl:grid-cols-4"
                    : "flex flex-col gap-3",
                )}
              >
                {items.map((p) => (
                  <ProductCard key={p.id} product={p} variant={viewMode} />
                ))}
              </div>

              {/* Infinite scroll sentinel */}
              {hasMoreInfinite && (
                <div ref={sentinelRef} className="flex items-center justify-center py-8">
                  {isFetchingNextPage ? (
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <div className="size-5 animate-spin rounded-full border-2 border-primary border-t-transparent" />
                      در حال بارگذاری...
                    </div>
                  ) : (
                    <div className="text-xs text-muted-foreground">اسکرول کنید</div>
                  )}
                </div>
              )}

              {/* Pagination — shows after page 5 loaded */}
              {showPagination && totalPages > 1 && (
                <div className="mt-8 flex items-center justify-center gap-1">
                  <p className="ml-4 text-sm text-muted-foreground nums-fa">
                    صفحه {toPersianDigits(INFINITE_PAGES)} از {toPersianDigits(totalPages)}
                  </p>
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => goToPage(currentPage - 1)}
                    disabled={currentPage <= INFINITE_PAGES}
                  >
                    <ChevronRight className="size-4" />
                  </Button>
                  {Array.from({ length: Math.min(totalPages - INFINITE_PAGES + 1, 7) }).map((_, i) => {
                    const page = INFINITE_PAGES + i;
                    if (page > totalPages) return null;
                    return (
                      <Button
                        key={page}
                        variant={page === currentPage ? "default" : "outline"}
                        size="icon"
                        onClick={() => goToPage(page)}
                        className="nums-fa"
                      >
                        {toPersianDigits(page)}
                      </Button>
                    );
                  })}
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => goToPage(currentPage + 1)}
                    disabled={currentPage >= totalPages}
                  >
                    <ChevronLeft className="size-4" />
                  </Button>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}

function ProductGridSkeleton({ count = 12, variant = "grid" }: { count?: number; variant?: "grid" | "list" }) {
  return (
    <div className={variant === "grid" ? "grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-4 lg:grid-cols-3 xl:grid-cols-4" : "flex flex-col gap-3"}>
      {Array.from({ length: count }).map((_, i) => (
        <ProductCardSkeleton key={i} variant={variant} />
      ))}
    </div>
  );
}

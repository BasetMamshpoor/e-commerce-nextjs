"use client";

import * as React from "react";
import { Check, X, MessageSquare } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { AdminTable } from "@/features/admin/components/admin-table";
import { commentsService } from "@/services";
import type { CommentStatus, PaginatedData, Comment } from "@/types/domain";
import { formatDateTimeFa, toPersianDigits } from "@/utils/format";

const STATUS_CONFIG: Record<CommentStatus, { label: string; variant: "default" | "secondary" | "destructive" }> = {
  PENDING: { label: "در انتظار", variant: "secondary" },
  APPROVED: { label: "تأیید شده", variant: "default" },
  REJECTED: { label: "رد شده", variant: "destructive" },
};

const STATUS_FILTERS: CommentStatus[] = ["PENDING", "APPROVED", "REJECTED"];

export default function AdminCommentsPage() {
  const [data, setData] = React.useState<PaginatedData<Comment> | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [page, setPage] = React.useState(1);
  const [statusFilter, setStatusFilter] = React.useState<CommentStatus | "">("");

  const load = React.useCallback(() => {
    setLoading(true);
    commentsService
      .adminList({ page, limit: 20, status: statusFilter || undefined })
      .then(setData)
      .finally(() => setLoading(false));
  }, [page, statusFilter]);

  React.useEffect(() => {
    load();
  }, [load]);

  const handleApprove = async (id: string) => {
    try {
      await commentsService.adminUpdate(id, { status: "APPROVED" });
      toast.success("نظر تأیید شد");
      load();
    } catch {
      toast.error("عملیات ناموفق بود");
    }
  };

  const handleReject = async (id: string) => {
    try {
      await commentsService.adminUpdate(id, { status: "REJECTED" });
      toast.success("نظر رد شد");
      load();
    } catch {
      toast.error("عملیات ناموفق بود");
    }
  };

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-xl font-bold text-foreground sm:text-2xl">نظرات</h1>
        <p className="mt-1 text-sm text-muted-foreground">مدیریت و تأیید نظرات کاربران</p>
      </div>

      {/* Status filter chips — at top */}
      <div className="flex flex-wrap gap-2">
        <button
          onClick={() => { setStatusFilter(""); setPage(1); }}
          className={`rounded-full px-3 py-1.5 text-xs font-medium transition-colors ${
            statusFilter === "" ? "bg-primary text-primary-foreground" : "bg-card border border-border text-muted-foreground hover:bg-accent"
          }`}
        >
          همه
        </button>
        {STATUS_FILTERS.map((status) => {
          const cfg = STATUS_CONFIG[status];
          return (
            <button
              key={status}
              onClick={() => { setStatusFilter(status); setPage(1); }}
              className={`rounded-full px-3 py-1.5 text-xs font-medium transition-colors ${
                statusFilter === status ? "bg-primary text-primary-foreground" : "bg-card border border-border text-muted-foreground hover:bg-accent"
              }`}
            >
              {cfg.label}
            </button>
          );
        })}
      </div>

      <AdminTable
        title=""
        columns={[
          {
            key: "content",
            header: "نظر",
            render: (c) => (
              <div className="max-w-md">
                <p className="line-clamp-2 text-sm text-foreground">{c.content}</p>
                {c.rating && (
                  <p className="mt-1 text-xs text-warning nums-fa">★ {toPersianDigits(c.rating)}</p>
                )}
              </div>
            ),
          },
          {
            key: "status",
            header: "وضعیت",
            render: (c) => {
              const cfg = STATUS_CONFIG[c.status ?? "PENDING"];
              return <Badge variant={cfg.variant}>{cfg.label}</Badge>;
            },
          },
          {
            key: "date",
            header: "تاریخ",
            render: (c) => (
              <span className="text-xs text-muted-foreground">{formatDateTimeFa(c.createdAt)}</span>
            ),
          },
          {
            key: "actions",
            header: "عملیات",
            align: "left",
            render: (c) => (
              <div className="flex gap-1">
                {c.status !== "APPROVED" && (
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-7 gap-1 text-xs text-green-600 hover:bg-green-50 hover:text-green-700"
                    onClick={() => handleApprove(c.id)}
                  >
                    <Check className="size-3.5" />
                    تأیید
                  </Button>
                )}
                {c.status !== "REJECTED" && (
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-7 gap-1 text-xs text-red-600 hover:bg-red-50 hover:text-red-700"
                    onClick={() => handleReject(c.id)}
                  >
                    <X className="size-3.5" />
                    رد
                  </Button>
                )}
              </div>
            ),
          },
        ]}
        data={data?.items ?? []}
        isLoading={loading}
        getRowId={(c) => c.id}
        page={page}
        totalPages={data?.meta.totalPages ?? 1}
        total={data?.meta.total ?? 0}
        onPageChange={setPage}
        emptyTitle="نظری موجود نیست"
      />
    </div>
  );
}

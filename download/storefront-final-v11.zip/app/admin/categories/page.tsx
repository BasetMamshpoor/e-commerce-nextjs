"use client";

import * as React from "react";
import { Plus, FolderTree, ChevronLeft, ChevronDown, Pencil, Trash2, Loader2 } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ConfirmDialog } from "@/components/common/confirm-dialog";
import { EmptyState } from "@/components/common/empty-state";
import { categoriesService } from "@/services";
import type { Category } from "@/types/domain";
import { cn } from "@/lib/utils";

export default function AdminCategoriesPage() {
  const [tree, setTree] = React.useState<Category[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [dialogOpen, setDialogOpen] = React.useState(false);
  const [editing, setEditing] = React.useState<Category | null>(null);
  const [deleteCat, setDeleteCat] = React.useState<Category | null>(null);
  const [deleting, setDeleting] = React.useState(false);

  const load = React.useCallback(() => {
    setLoading(true);
    categoriesService.tree().then(setTree).finally(() => setLoading(false));
  }, []);

  React.useEffect(() => { load(); }, [load]);

  const handleDelete = async () => {
    if (!deleteCat) return;
    setDeleting(true);
    try {
      await categoriesService.delete(deleteCat.id);
      toast.success("دسته حذف شد");
      setDeleteCat(null);
      load();
    } catch {
      toast.error("حذف ناموفق — زیرمجموعه دارد");
    } finally {
      setDeleting(false);
    }
  };

  // Flatten tree for parent select
  const flatCats = React.useMemo(() => {
    const result: { id: string; name: string; depth: number }[] = [];
    const walk = (cats: Category[], depth: number) => {
      for (const c of cats) {
        result.push({ id: c.id, name: c.name, depth });
        if (c.children) walk(c.children, depth + 1);
      }
    };
    walk(tree, 0);
    return result.filter((c) => c.id !== editing?.id);
  }, [tree, editing]);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-foreground sm:text-2xl">دسته‌بندی‌ها</h1>
          <p className="mt-1 text-sm text-muted-foreground">مدیریت درخت دسته‌بندی محصولات</p>
        </div>
        <Button onClick={() => { setEditing(null); setDialogOpen(true); }}>
          <Plus className="size-4" />
          دسته جدید
        </Button>
      </div>

      {loading ? (
        <div className="space-y-2">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-14 w-full rounded-lg" />
          ))}
        </div>
      ) : tree.length === 0 ? (
        <EmptyState
          icon={<FolderTree className="size-16" />}
          title="دسته‌بندی‌ای موجود نیست"
          description="اولین دسته‌بندی را ایجاد کنید."
          className="border border-dashed border-border rounded-xl"
        />
      ) : (
        <div className="space-y-1">
          {tree.map((cat) => (
            <CategoryNode
              key={cat.id}
              category={cat}
              depth={0}
              onEdit={(c) => { setEditing(c); setDialogOpen(true); }}
              onDelete={(c) => setDeleteCat(c)}
            />
          ))}
        </div>
      )}

      <CategoryFormDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        category={editing}
        flatCats={flatCats}
        onSaved={load}
      />

      <ConfirmDialog
        open={!!deleteCat}
        onOpenChange={(open) => !open && setDeleteCat(null)}
        title="حذف دسته‌بندی"
        description={`آیا از حذف «${deleteCat?.name ?? ""}» مطمئن هستید؟ اگر زیرمجموعه داشته باشد، حذف امکان‌پذیر نیست.`}
        confirmText="حذف"
        variant="destructive"
        onConfirm={handleDelete}
        loading={deleting}
      />
    </div>
  );
}

/* ───────── Tree Node ───────── */

function CategoryNode({
  category,
  depth,
  onEdit,
  onDelete,
}: {
  category: Category;
  depth: number;
  onEdit: (c: Category) => void;
  onDelete: (c: Category) => void;
}) {
  const [expanded, setExpanded] = React.useState(true);
  const hasChildren = category.children && category.children.length > 0;

  return (
    <>
      <div
        className="flex items-center gap-2 rounded-lg border border-border/40 bg-card px-3 py-2 transition-colors hover:border-primary/20"
        style={{ paddingRight: `${depth * 20 + 12}px` }}
      >
        {/* Expand/collapse */}
        {hasChildren ? (
          <button
            onClick={() => setExpanded((v) => !v)}
            className="flex size-5 items-center justify-center rounded text-muted-foreground hover:bg-accent"
          >
            {expanded ? <ChevronDown className="size-3.5" /> : <ChevronLeft className="size-3.5" />}
          </button>
        ) : (
          <span className="w-5" />
        )}

        {/* Icon */}
        <span className="flex size-7 items-center justify-center rounded-md bg-primary/10 text-primary">
          <FolderTree className="size-3.5" />
        </span>

        {/* Name + slug */}
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <span className="truncate text-sm font-medium text-foreground">{category.name}</span>
            {!category.isActive && <Badge variant="secondary" className="text-[10px]">غیرفعال</Badge>}
            {hasChildren && (
              <span className="text-[10px] text-muted-foreground nums-fa">
                {category.children!.length} زیردسته
              </span>
            )}
          </div>
          <span className="text-[10px] text-muted-foreground" dir="ltr">/{category.slug}</span>
        </div>

        {/* Actions */}
        <Button variant="ghost" size="icon" className="size-7" onClick={() => onEdit(category)}>
          <Pencil className="size-3.5" />
        </Button>
        <Button
          variant="ghost"
          size="icon"
          className="size-7 text-muted-foreground hover:text-destructive"
          onClick={() => onDelete(category)}
        >
          <Trash2 className="size-3.5" />
        </Button>
      </div>

      {/* Children */}
      {expanded && hasChildren && (
        <div className="space-y-1">
          {category.children!.map((child) => (
            <CategoryNode
              key={child.id}
              category={child}
              depth={depth + 1}
              onEdit={onEdit}
              onDelete={onDelete}
            />
          ))}
        </div>
      )}
    </>
  );
}

/* ───────── Form Dialog ───────── */

function CategoryFormDialog({
  open,
  onOpenChange,
  category,
  flatCats,
  onSaved,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  category: Category | null;
  flatCats: { id: string; name: string; depth: number }[];
  onSaved: () => void;
}) {
  const [name, setName] = React.useState("");
  const [slug, setSlug] = React.useState("");
  const [description, setDescription] = React.useState("");
  const [parentId, setParentId] = React.useState("");
  const [isActive, setIsActive] = React.useState(true);
  const [saving, setSaving] = React.useState(false);

  React.useEffect(() => {
    if (open) {
      setName(category?.name ?? "");
      setSlug(category?.slug ?? "");
      setDescription(category?.description ?? "");
      setParentId(category?.parentId ?? "");
      setIsActive(category?.isActive ?? true);
    }
  }, [open, category]);

  const onSubmit = async () => {
    if (!name.trim()) {
      toast.error("نام الزامی است");
      return;
    }
    setSaving(true);
    try {
      const body = {
        name,
        slug: slug || undefined,
        description: description || undefined,
        parentId: parentId || undefined,
        isActive,
      };
      if (category) {
        await categoriesService.update(category.id, body);
        toast.success("دسته به‌روزرسانی شد");
      } else {
        await categoriesService.create(body);
        toast.success("دسته ایجاد شد");
      }
      onOpenChange(false);
      onSaved();
    } catch {
      toast.error("ذخیره ناموفق بود");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{category ? "ویرایش دسته" : "دسته جدید"}</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-2">
          <div className="space-y-2">
            <Label>نام *</Label>
            <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="مثال: موبایل" />
          </div>
          <div className="space-y-2">
            <Label>اسلاگ (اختیاری)</Label>
            <Input value={slug} onChange={(e) => setSlug(e.target.value)} placeholder="mobile" dir="ltr" />
            <p className="text-xs text-muted-foreground">اگر خالی بگذارید، خودکار ساخته می‌شود.</p>
          </div>
          <div className="space-y-2">
            <Label>دسته والد</Label>
            <Select value={parentId} onValueChange={setParentId}>
              <SelectTrigger>
                <SelectValue placeholder="بدون والد (دسته اصلی)" />
              </SelectTrigger>
              <SelectContent>
                {flatCats.map((c) => (
                  <SelectItem key={c.id} value={c.id}>
                    {"—".repeat(c.depth)} {c.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>توضیحات</Label>
            <Textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={2} />
          </div>
          <label className="flex items-center gap-2">
            <input type="checkbox" checked={isActive} onChange={(e) => setIsActive(e.target.checked)} className="size-4 rounded" />
            <span className="text-sm">فعال</span>
          </label>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>انصراف</Button>
          <Button onClick={onSubmit} disabled={saving}>
            {saving ? <Loader2 className="size-4 animate-spin" /> : null}
            {category ? "ذخیره تغییرات" : "ایجاد دسته"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

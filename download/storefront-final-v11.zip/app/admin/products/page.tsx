"use client";

import * as React from "react";
import Link from "next/link";
import { Plus, Trash2, Eye, Pencil, Loader2 } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { AdminTable } from "@/features/admin/components/admin-table";
import { productsService } from "@/services";
import type { PaginatedData, Product, ProductStatus } from "@/types/domain";
import { formatPrice, toPersianDigits, formatDateTimeFa } from "@/utils/format";

const STATUS_CONFIG: Record<ProductStatus, { label: string; variant: "default" | "secondary" | "destructive" }> = {
  PUBLISHED: { label: "منتشر شده", variant: "default" },
  DRAFT: { label: "پیش‌نویس", variant: "secondary" },
  ARCHIVED: { label: "آرشیو شده", variant: "destructive" },
};

const STATUS_FILTERS: ProductStatus[] = ["PUBLISHED", "DRAFT", "ARCHIVED"];

export default function AdminProductsPage() {
  const [data, setData] = React.useState<PaginatedData<Product> | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [page, setPage] = React.useState(1);
  const [search, setSearch] = React.useState("");
  const [statusFilter, setStatusFilter] = React.useState<ProductStatus | "">("");
  const [deleteId, setDeleteId] = React.useState<string | null>(null);
  const [deleting, setDeleting] = React.useState(false);

  const load = React.useCallback(() => {
    setLoading(true);
    productsService
      .adminList({ page, limit: 20, search: search || undefined, status: statusFilter || undefined })
      .then(setData)
      .finally(() => setLoading(false));
  }, [page, search, statusFilter]);

  React.useEffect(() => {
    load();
  }, [load]);

  const handleDelete = async () => {
    if (!deleteId) return;
    setDeleting(true);
    try {
      await productsService.delete(deleteId);
      toast.success("محصول حذف شد");
      setDeleteId(null);
      load();
    } catch {
      toast.error("حذف ناموفق — در سفارش استفاده شده");
    } finally {
      setDeleting(false);
    }
  };

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-xl font-bold text-foreground sm:text-2xl">محصولات</h1>
        <p className="mt-1 text-sm text-muted-foreground">مدیریت محصولات فروشگاه</p>
      </div>

      {/* Status filter chips */}
      <div className="flex flex-wrap gap-2">
        <button
          onClick={() => { setStatusFilter(""); setPage(1); }}
          className={`rounded-full px-3 py-1.5 text-xs font-medium transition-colors ${
            statusFilter === "" ? "bg-primary text-primary-foreground" : "bg-card border border-border text-muted-foreground hover:bg-accent"
          }`}
        >
          همه
        </button>
        {STATUS_FILTERS.map((status) => {
          const cfg = STATUS_CONFIG[status];
          return (
            <button
              key={status}
              onClick={() => { setStatusFilter(status); setPage(1); }}
              className={`rounded-full px-3 py-1.5 text-xs font-medium transition-colors ${
                statusFilter === status ? "bg-primary text-primary-foreground" : "bg-card border border-border text-muted-foreground hover:bg-accent"
              }`}
            >
              {cfg.label}
            </button>
          );
        })}
      </div>

      <AdminTable
        title=""
        columns={[
          {
            key: "name",
            header: "نام محصول",
            render: (p) => (
              <Link href={`/admin/products/${p.id}`} className="font-medium text-foreground hover:text-primary">
                {p.name}
              </Link>
            ),
          },
          {
            key: "brand",
            header: "برند",
            hideOnMobile: true,
            render: (p) => p.brand?.name ?? "—",
          },
          {
            key: "price",
            header: "قیمت",
            align: "left",
            render: (p) => (
              <span className="nums-fa">
                {p.minPrice === p.maxPrice ? formatPrice(p.minPrice) : `${formatPrice(p.minPrice)} - ${formatPrice(p.maxPrice)}`}
              </span>
            ),
          },
          {
            key: "stock",
            header: "موجودی",
            align: "center",
            render: (p) => (
              <Badge variant={p.isInStock ? "default" : "destructive"}>
                {p.isInStock ? "موجود" : "ناموجود"}
              </Badge>
            ),
          },
          {
            key: "status",
            header: "وضعیت",
            render: (p) => {
              const cfg = STATUS_CONFIG[p.status];
              return <Badge variant={cfg.variant}>{cfg.label}</Badge>;
            },
          },
          {
            key: "createdAt",
            header: "تاریخ",
            hideOnMobile: true,
            render: (p) => (
              <span className="text-xs text-muted-foreground">{formatDateTimeFa(p.createdAt)}</span>
            ),
          },
          {
            key: "actions",
            header: "",
            align: "left",
            render: (p) => (
              <div className="flex gap-1">
                <Button asChild variant="ghost" size="icon" className="size-8">
                  <Link href={`/admin/products/${p.id}`}>
                    <Eye className="size-4" />
                  </Link>
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  className="size-8 text-muted-foreground hover:text-destructive"
                  onClick={() => setDeleteId(p.id)}
                >
                  <Trash2 className="size-4" />
                </Button>
              </div>
            ),
          },
        ]}
        data={data?.items ?? []}
        isLoading={loading}
        getRowId={(p) => p.id}
        getRowHref={(p) => `/admin/products/${p.id}`}
        page={page}
        totalPages={data?.meta.totalPages ?? 1}
        total={data?.meta.total ?? 0}
        onPageChange={setPage}
        searchValue={search}
        onSearchChange={(v) => { setSearch(v); setPage(1); }}
        searchPlaceholder="جست‌وجوی محصول..."
        emptyTitle="محصولی یافت نشد"
        headerActions={
          <Button asChild>
            <Link href="/admin/products/new">
              <Plus className="size-4" />
              محصول جدید
            </Link>
          </Button>
        }
      />

      {/* Delete AlertDialog */}
      <AlertDialog open={!!deleteId} onOpenChange={(open) => !open && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>حذف محصول</AlertDialogTitle>
            <AlertDialogDescription>
              آیا از حذف این محصول مطمئن هستید؟ اگر در سفارشی استفاده شده باشد، حذف امکان‌پذیر نخواهد بود. پیشنهاد می‌شود به‌جای حذف، وضعیت را به «آرشیو شده» تغییر دهید.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>انصراف</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              disabled={deleting}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {deleting ? <Loader2 className="size-4 animate-spin" /> : null}
              حذف
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

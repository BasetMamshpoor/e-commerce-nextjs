"use client";

import * as React from "react";
import { Save, Loader2 } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Separator } from "@/components/ui/separator";
import { settingsService } from "@/services";
import type { Setting } from "@/types/domain";

const SETTING_LABELS: Record<string, string> = {
  site_name: "نام فروشگاه",
  site_description: "توضیحات فروشگاه",
  contact_email: "ایمیل تماس",
  contact_phone: "تلفن تماس",
  default_currency: "واحد پول پیش‌فرض",
  tax_rate: "نرخ مالیات",
  free_shipping_threshold: "حداقل مبلغ ارسال رایگان",
  instagram: "لینک اینستاگرام",
  telegram: "لینک تلگرام",
  whatsapp: "لینک واتساپ",
  maintenance_mode: "حالت تعمیر",
};

// Group settings into categories for better layout
const SETTING_GROUPS: { title: string; keys: string[] }[] = [
  { title: "اطلاعات فروشگاه", keys: ["site_name", "site_description", "contact_email", "contact_phone"] },
  { title: "فروش و ارسال", keys: ["default_currency", "tax_rate", "free_shipping_threshold"] },
  { title: "شبکه‌های اجتماعی", keys: ["instagram", "telegram", "whatsapp"] },
  { title: "سیستم", keys: ["maintenance_mode"] },
];

export default function AdminSettingsPage() {
  const [settings, setSettings] = React.useState<Setting[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [saving, setSaving] = React.useState<Record<string, boolean>>({});
  const [values, setValues] = React.useState<Record<string, string>>({});

  React.useEffect(() => {
    settingsService.adminList().then((data) => {
      setSettings(data);
      const map: Record<string, string> = {};
      data.forEach((s) => (map[s.key] = s.value));
      setValues(map);
    }).finally(() => setLoading(false));
  }, []);

  const onSave = async (key: string) => {
    setSaving((s) => ({ ...s, [key]: true }));
    try {
      const setting = settings.find((s) => s.key === key);
      await settingsService.upsert(key, {
        value: values[key],
        type: setting?.type ?? "string",
      });
      toast.success(`تنظیم «${SETTING_LABELS[key] ?? key}» ذخیره شد`);
    } catch {
      toast.error("ذخیره ناموفق بود");
    } finally {
      setSaving((s) => ({ ...s, [key]: false }));
    }
  };

  if (loading) {
    return (
      <div className="space-y-3">
        {Array.from({ length: 6 }).map((_, i) => (
          <Skeleton key={i} className="h-16 w-full rounded-xl" />
        ))}
      </div>
    );
  }

  // Get settings that don't belong to any group
  const groupedKeys = SETTING_GROUPS.flatMap((g) => g.keys);
  const ungrouped = settings.filter((s) => !groupedKeys.includes(s.key));

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-xl font-bold text-foreground sm:text-2xl">تنظیمات سایت</h1>
        <p className="mt-1 text-sm text-muted-foreground">مدیریت تنظیمات سراسری</p>
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        {SETTING_GROUPS.map((group) => {
          const groupSettings = settings.filter((s) => group.keys.includes(s.key));
          if (groupSettings.length === 0) return null;

          return (
            <Card key={group.title}>
              <CardHeader className="pb-3">
                <CardTitle className="text-base">{group.title}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {groupSettings.map((s) => (
                  <div key={s.key} className="grid grid-cols-[1fr_auto] items-end gap-2">
                    <div className="space-y-1.5">
                      <Label className="text-sm font-medium">
                        {SETTING_LABELS[s.key] ?? s.key}
                      </Label>
                      <Input
                        value={values[s.key] ?? ""}
                        onChange={(e) => setValues({ ...values, [s.key]: e.target.value })}
                        dir={s.type === "number" || s.key.includes("url") || s.key.includes("email") ? "ltr" : "rtl"}
                      />
                    </div>
                    <Button
                      size="icon"
                      variant="outline"
                      onClick={() => onSave(s.key)}
                      disabled={saving[s.key]}
                      className="size-9"
                    >
                      {saving[s.key] ? <Loader2 className="size-4 animate-spin" /> : <Save className="size-4" />}
                    </Button>
                  </div>
                ))}
              </CardContent>
            </Card>
          );
        })}

        {/* Ungrouped settings */}
        {ungrouped.length > 0 && (
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">سایر تنظیمات</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {ungrouped.map((s) => (
                <div key={s.key} className="grid grid-cols-[1fr_auto] items-end gap-2">
                  <div className="space-y-1.5">
                    <Label className="text-sm font-medium">
                      {SETTING_LABELS[s.key] ?? s.key}
                    </Label>
                    <Input
                      value={values[s.key] ?? ""}
                      onChange={(e) => setValues({ ...values, [s.key]: e.target.value })}
                      dir={s.type === "number" || s.key.includes("url") || s.key.includes("email") ? "ltr" : "rtl"}
                    />
                  </div>
                  <Button
                    size="icon"
                    variant="outline"
                    onClick={() => onSave(s.key)}
                    disabled={saving[s.key]}
                    className="size-9"
                  >
                    {saving[s.key] ? <Loader2 className="size-4 animate-spin" /> : <Save className="size-4" />}
                  </Button>
                </div>
              ))}
            </CardContent>
          </Card>
        )}
      </div>

      {settings.length === 0 && (
        <div className="py-12 text-center text-sm text-muted-foreground">
          تنظیمی موجود نیست
        </div>
      )}
    </div>
  );
}

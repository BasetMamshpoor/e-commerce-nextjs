"use client";

import * as React from "react";
import Link from "next/link";
import { FolderTree, ChevronDown } from "lucide-react";

import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuTrigger,
  NavigationMenuLink,
  NavigationMenuList,
  navigationMenuTriggerStyle,
} from "@/components/ui/navigation-menu";
import { Skeleton } from "@/components/ui/skeleton";
import { useCategoriesTree } from "@/features/catalog/hooks";
import type { Category } from "@/types/domain";
import { cn } from "@/lib/utils";

export function CategoryNavMenu() {
  const { data: tree, isLoading } = useCategoriesTree();

  if (isLoading) {
    return <Skeleton className="h-8 w-32" />;
  }

  if (!tree || tree.length === 0) {
    return (
      <Link href="/products" className="text-sm text-muted-foreground hover:text-primary">
        همه محصولات
      </Link>
    );
  }

  return (
    <NavigationMenu>
      <NavigationMenuList>
        <NavigationMenuItem>
          <NavigationMenuTrigger className="gap-1.5 text-sm font-medium text-foreground">
            <FolderTree className="size-4 text-primary" />
            دسته‌بندی‌ها
          </NavigationMenuTrigger>
          <NavigationMenuContent>
            <div className="grid w-[480px] gap-1 p-3 md:grid-cols-2">
              {tree.map((cat) => (
                <CategoryMegaItem key={cat.id} category={cat} />
              ))}
            </div>
          </NavigationMenuContent>
        </NavigationMenuItem>
      </NavigationMenuList>
    </NavigationMenu>
  );
}

function CategoryMegaItem({ category }: { category: Category }) {
  const children = category.children ?? [];

  return (
    <div className="group/item rounded-lg p-2 transition-colors hover:bg-accent">
      <Link
        href={`/categories/${category.slug}`}
        className="flex items-center justify-between text-sm font-medium text-foreground hover:text-primary"
      >
        {category.name}
        {children.length > 0 && <ChevronDown className="size-3.5 text-muted-foreground" />}
      </Link>
      {children.length > 0 && (
        <div className="mt-1 space-y-0.5 pr-3">
          {children.slice(0, 5).map((child) => (
            <Link
              key={child.id}
              href={`/categories/${child.slug}`}
              className="block rounded-md px-2 py-1 text-xs text-muted-foreground hover:bg-accent hover:text-accent-foreground"
            >
              {child.name}
            </Link>
          ))}
          {children.length > 5 && (
            <Link
              href={`/categories/${category.slug}`}
              className="block rounded-md px-2 py-1 text-xs text-primary hover:underline"
            >
              + {children.length - 5} مورد دیگر
            </Link>
          )}
        </div>
      )}
    </div>
  );
}

"use client";

import * as React from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { SlidersHorizontal, X } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Separator } from "@/components/ui/separator";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { Skeleton } from "@/components/ui/skeleton";
import { Slider } from "@/components/ui/slider";
import { MultiSelectCombobox } from "@/components/common/multi-select-combobox";
import { useProductFilters } from "@/features/catalog/hooks/use-product-filters";
import { formatPrice } from "@/utils/format";

interface FilterSidebarProps {
  categorySlug?: string;
}

export function FilterSidebar({ categorySlug }: FilterSidebarProps) {
  const { data: filters, isLoading } = useProductFilters(categorySlug);
  const router = useRouter();
  const searchParams = useSearchParams();

  const selectedBrandIds = searchParams.get("brandIds")?.split(",").filter(Boolean) ?? [];
  const selectedAttrValueIds = searchParams.get("attributeValueIds")?.split(",").filter(Boolean) ?? [];

  const minPriceParam = searchParams.get("minPrice");
  const maxPriceParam = searchParams.get("maxPrice");

  const updateParams = (updates: Record<string, string | null>) => {
    const params = new URLSearchParams(searchParams.toString());
    for (const [key, val] of Object.entries(updates)) {
      if (val === null || val === "") params.delete(key);
      else params.set(key, val);
    }
    params.delete("page");
    const qs = params.toString();
    router.replace(qs ? `/products?${qs}` : "/products", { scroll: false });
  };

  const toggleBoolean = (key: "inStock" | "hasDiscount") => {
    const current = searchParams.get(key) === "true";
    updateParams({ [key]: current ? null : "true" });
  };

  // Price slider
  const priceMin = filters?.priceRange.min ?? 0;
  const priceMax = filters?.priceRange.max ?? 10000000;
  const currentMin = minPriceParam ? Number(minPriceParam) : priceMin;
  const currentMax = maxPriceParam ? Number(maxPriceParam) : priceMax;

  const onPriceSliderChange = (values: number[]) => {
    updateParams({
      minPrice: values[0] > priceMin ? String(values[0]) : null,
      maxPrice: values[1] < priceMax ? String(values[1]) : null,
    });
  };

  const hasActiveFilters =
    selectedBrandIds.length > 0 ||
    selectedAttrValueIds.length > 0 ||
    searchParams.get("inStock") === "true" ||
    searchParams.get("hasDiscount") === "true" ||
    minPriceParam ||
    maxPriceParam;

  return (
    <div className="rounded-xl border border-border bg-card p-4">
      {/* Header */}
      <div className="mb-4 flex items-center justify-between">
        <h3 className="flex items-center gap-2 text-sm font-bold text-foreground">
          <SlidersHorizontal className="size-4 text-primary" />
          فیلترها
        </h3>
        {hasActiveFilters && (
          <Button
            variant="ghost"
            size="sm"
            className="h-7 text-xs text-muted-foreground hover:text-destructive"
            onClick={() => router.replace("/products", { scroll: false })}
          >
            <X className="size-3" />
            پاک کردن
          </Button>
        )}
      </div>

      <div className="space-y-4">
        {/* Quick filters */}
        <FilterSection title="وضعیت">
          <FilterCheckbox
            label="فقط کالاهای موجود"
            checked={searchParams.get("inStock") === "true"}
            onChange={() => toggleBoolean("inStock")}
          />
          <FilterCheckbox
            label="فقط کالاهای تخفیف‌دار"
            checked={searchParams.get("hasDiscount") === "true"}
            onChange={() => toggleBoolean("hasDiscount")}
          />
        </FilterSection>

        {/* Price range with slider */}
        {filters && priceMax > 0 && (
          <FilterSection title="بازه قیمت">
            <div className="space-y-3">
              <Slider
                defaultValue={[currentMin, currentMax]}
                min={priceMin}
                max={priceMax}
                step={(priceMax - priceMin) / 100}
                onValueChange={onPriceSliderChange}
                className="mt-2"
                dir="ltr"
              />
              <div className="flex items-center justify-between text-xs text-muted-foreground">
                <span className="nums-fa">{formatPrice(currentMin)}</span>
                <span className="nums-fa">{formatPrice(currentMax)}</span>
              </div>
            </div>
          </FilterSection>
        )}

        {/* Brands as combobox */}
        {isLoading ? (
          <FilterSection title="برندها">
            <Skeleton className="h-9 w-full" />
          </FilterSection>
        ) : filters && filters.brands.length > 0 ? (
          <FilterSection title="برندها">
            <MultiSelectCombobox
              options={filters.brands.map((b) => ({ value: b.id, label: b.name }))}
              value={selectedBrandIds}
              onChange={(vals) => {
                updateParams({
                  brandIds: vals.length ? vals.join(",") : null,
                });
              }}
              placeholder="انتخاب برند..."
              searchPlaceholder="جست‌وجوی برند..."
              emptyText="بری یافت نشد"
            />
          </FilterSection>
        ) : null}

        {/* Dynamic attributes — ALL as comboboxes, no accordion */}
        {filters && filters.attributes.length > 0 && (
          <>
            {filters.attributes.map((attr) => (
              <FilterSection key={attr.id} title={attr.name}>
                <MultiSelectCombobox
                  options={attr.values.map((v) => ({
                    value: v.id,
                    label: v.value,
                    colorHex: v.colorHex,
                  }))}
                  value={selectedAttrValueIds.filter((id) =>
                    attr.values.some((v) => v.id === id),
                  )}
                  onChange={(vals) => {
                    const otherAttrs = selectedAttrValueIds.filter((id) =>
                      !attr.values.some((v) => v.id === id),
                    );
                    const next = [...otherAttrs, ...vals];
                    updateParams({
                      attributeValueIds: next.length ? next.join(",") : null,
                    });
                  }}
                  placeholder={`انتخاب ${attr.name}...`}
                  searchPlaceholder="جست‌وجو..."
                  emptyText="موردی یافت نشد"
                />
              </FilterSection>
            ))}
          </>
        )}
      </div>
    </div>
  );
}

function FilterSection({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="space-y-2">
      <h4 className="text-xs font-semibold text-muted-foreground">{title}</h4>
      <div className="space-y-1.5">{children}</div>
    </div>
  );
}

function FilterCheckbox({
  label,
  checked,
  onChange,
}: {
  label: string;
  checked: boolean;
  onChange: () => void;
}) {
  const id = React.useId();
  return (
    <div className="flex items-center gap-2">
      <Checkbox id={id} checked={checked} onCheckedChange={onChange} />
      <Label htmlFor={id} className="text-sm font-normal text-muted-foreground cursor-pointer">
        {label}
      </Label>
    </div>
  );
}

/* ───────── Mobile sheet wrapper ───────── */

export function MobileFilterSheet(props: FilterSidebarProps) {
  const [open, setOpen] = React.useState(false);
  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <Button variant="outline" size="sm" className="lg:hidden">
          <SlidersHorizontal className="size-4" />
          فیلترها
        </Button>
      </SheetTrigger>
      <SheetContent side="right" className="w-full overflow-y-auto sm:w-96">
        <SheetHeader>
          <SheetTitle>فیلترها</SheetTitle>
        </SheetHeader>
        <div className="mt-4">
          <FilterSidebar {...props} />
        </div>
      </SheetContent>
    </Sheet>
  );
}

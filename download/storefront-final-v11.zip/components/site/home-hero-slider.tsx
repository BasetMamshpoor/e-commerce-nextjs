"use client";

import * as React from "react";
import Image from "next/image";
import Link from "next/link";
import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay, Pagination, Navigation } from "swiper/modules";
import { ArrowLeft, ChevronLeft, ChevronRight } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useBanners } from "@/features/catalog/hooks/use-banners";
import type { Banner } from "@/types/domain";
import { cn } from "@/lib/utils";

import "swiper/css";
import "swiper/css/pagination";
import "swiper/css/navigation";

export function HomeHeroSlider() {
  const { data: banners, isLoading } = useBanners("HOME_MAIN");

  const slides: HeroSlide[] = React.useMemo(() => {
    if (isLoading || !banners || banners.length === 0) {
      return [FALLBACK_SLIDE];
    }
    return banners.map((b) => ({
      id: b.id,
      title: b.title,
      imageUrl: b.imageUrl,
      link: b.link ?? "/products",
      isFallback: false,
    }));
  }, [banners, isLoading]);

  return (
    <section className="mb-6" aria-label="اسلایدر اصلی">
      <div className="relative overflow-hidden rounded-2xl">
        <Swiper
          modules={[Autoplay, Pagination, Navigation]}
          autoplay={{ delay: 5000, disableOnInteraction: false }}
          pagination={{ clickable: true, bulletActiveClass: "swiper-pagination-bullet-active !bg-primary !w-6 !rounded-full", bulletClass: "swiper-pagination-bullet !bg-white/60 !w-2.5 !h-2.5 !rounded-full !opacity-100 transition-all" }}
          navigation={{
            nextEl: ".hero-next",
            prevEl: ".hero-prev",
          }}
          loop={slides.length > 1}
          className="!pb-0"
        >
          {slides.map((slide, i) => (
            <SwiperSlide key={slide.id}>
              <HeroSlideView slide={slide} isLoading={isLoading && i === 0} />
            </SwiperSlide>
          ))}
        </Swiper>

        {/* Custom navigation */}
        {slides.length > 1 && (
          <>
            <button className="hero-prev absolute right-2 top-1/2 z-10 flex size-9 -translate-y-1/2 items-center justify-center rounded-full bg-background/80 text-foreground shadow-md backdrop-blur hover:bg-background">
              <ChevronRight className="size-5" />
            </button>
            <button className="hero-next absolute left-2 top-1/2 z-10 flex size-9 -translate-y-1/2 items-center justify-center rounded-full bg-background/80 text-foreground shadow-md backdrop-blur hover:bg-background">
              <ChevronLeft className="size-5" />
            </button>
          </>
        )}
      </div>
    </section>
  );
}

interface HeroSlide {
  id: string;
  title: string;
  imageUrl?: string;
  link: string;
  isFallback?: boolean;
}

const FALLBACK_SLIDE: HeroSlide = {
  id: "fallback",
  title: "خریدی آسان، با تحویل سریع و پرداخت امن",
  imageUrl: undefined,
  link: "/products",
  isFallback: true,
};

function HeroSlideView({ slide, isLoading }: { slide: HeroSlide; isLoading: boolean }) {
  if (isLoading) {
    return <Skeleton className="aspect-[2/1] w-full rounded-2xl sm:aspect-[3/1]" />;
  }

  if (slide.isFallback || !slide.imageUrl) {
    return (
      <div className="relative aspect-[2/1] w-full overflow-hidden rounded-2xl bg-gradient-to-l from-primary via-red-600 to-red-800 px-6 py-10 text-primary-foreground shadow-xl sm:aspect-[3/1] sm:px-12 sm:py-16">
        <div className="relative z-10 max-w-2xl">
          <span className="mb-4 inline-flex items-center gap-1.5 rounded-full bg-white/20 px-3 py-1 text-xs font-medium backdrop-blur-md">
            جشنواره تابستانه
          </span>
          <h2 className="mb-4 text-2xl font-bold leading-tight sm:text-4xl lg:text-5xl">
            {slide.title}
          </h2>
          <p className="mb-6 text-sm text-primary-foreground/90 sm:text-lg">
            از جدیدترین محصولات با بهترین قیمت‌ها خرید کنید. ارسال رایگان برای
            سفارش‌های بالای ۵۰۰٬۰۰۰ تومان.
          </p>
          <Button asChild size="lg" variant="secondary" className="shadow-lg">
            <Link href={slide.link}>
              مشاهده محصولات
              <ArrowLeft className="size-4" />
            </Link>
          </Button>
        </div>
        <div className="absolute -left-20 -top-20 size-72 rounded-full bg-white/10 blur-3xl" />
        <div className="absolute -bottom-32 left-1/3 size-96 rounded-full bg-white/5 blur-3xl" />
        <div className="absolute right-10 top-10 hidden text-9xl font-bold text-white/5 sm:block">
          فروش
        </div>
      </div>
    );
  }

  return (
    <Link
      href={slide.link}
      className="relative block aspect-[2/1] w-full overflow-hidden rounded-2xl bg-muted shadow-xl sm:aspect-[3/1]"
      aria-label={slide.title}
    >
      <Image
        src={slide.imageUrl}
        alt={slide.title}
        fill
        priority
        sizes="(max-width: 768px) 100vw, 1200px"
        className="object-cover"
      />
      <div className="absolute inset-0 bg-gradient-to-l from-black/60 via-black/20 to-transparent" />
      <div className="absolute inset-0 flex items-center px-6 sm:px-12">
        <h2 className="max-w-md text-xl font-bold text-white drop-shadow-lg sm:text-3xl lg:text-4xl">
          {slide.title}
        </h2>
      </div>
    </Link>
  );
}

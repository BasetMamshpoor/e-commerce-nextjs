"use client";

import * as React from "react";
import { Search, ChevronLeft, ChevronRight } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { EmptyState } from "@/components/common/empty-state";
import { cn } from "@/lib/utils";
import { toPersianDigits } from "@/utils/format";

interface AdminTableColumn<T> {
  key: string;
  header: string;
  render: (item: T) => React.ReactNode;
  className?: string;
  align?: "right" | "left" | "center";
  /** Hide this column on mobile card view */
  hideOnMobile?: boolean;
}

interface AdminTableProps<T> {
  columns: AdminTableColumn<T>[];
  data: T[];
  isLoading?: boolean;
  getRowId: (item: T) => string;
  onRowClick?: (item: T) => void;
  getRowHref?: (item: T) => string;
  emptyTitle?: string;
  emptyDescription?: string;
  emptyAction?: React.ReactNode;
  page?: number;
  totalPages?: number;
  total?: number;
  onPageChange?: (page: number) => void;
  searchValue?: string;
  onSearchChange?: (value: string) => void;
  searchPlaceholder?: string;
  headerActions?: React.ReactNode;
  title: string;
  description?: string;
}

export function AdminTable<T>({
  columns,
  data,
  isLoading,
  getRowId,
  getRowHref,
  emptyTitle = "موردی یافت نشد",
  emptyDescription = "برای افزودن، از دکمه بالا استفاده کنید.",
  emptyAction,
  page = 1,
  totalPages = 1,
  total = 0,
  onPageChange,
  searchValue,
  onSearchChange,
  searchPlaceholder = "جست‌وجو...",
  headerActions,
  title,
  description,
}: AdminTableProps<T>) {
  return (
    <div className="space-y-4">
      {/* Header */}
      {title && (
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-xl font-bold text-foreground sm:text-2xl">{title}</h1>
            {description && <p className="mt-1 text-sm text-muted-foreground">{description}</p>}
          </div>
          {headerActions}
        </div>
      )}

      {/* Search */}
      {onSearchChange && (
        <div className="relative max-w-sm">
          <Search className="pointer-events-none absolute right-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            type="search"
            placeholder={searchPlaceholder}
            value={searchValue ?? ""}
            onChange={(e) => onSearchChange(e.target.value)}
            className="pr-9"
          />
        </div>
      )}

      {/* Desktop: table / Mobile: cards */}
      {isLoading ? (
        <div className="space-y-2">
          {Array.from({ length: 5 }).map((_, i) => (
            <Skeleton key={i} className="h-16 w-full rounded-xl" />
          ))}
        </div>
      ) : data.length === 0 ? (
        <EmptyState
          title={emptyTitle}
          description={emptyDescription}
          action={emptyAction}
          className="border border-dashed border-border rounded-xl"
        />
      ) : (
        <>
          {/* Desktop table */}
          <div className="hidden overflow-hidden rounded-xl border border-border bg-card lg:block">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border bg-muted/30">
                  {columns.map((col) => (
                    <th
                      key={col.key}
                      className={cn(
                        "whitespace-nowrap px-4 py-3 text-xs font-semibold text-muted-foreground",
                        col.align === "left" && "text-left",
                        col.align === "center" && "text-center",
                        (!col.align || col.align === "right") && "text-right",
                        col.className,
                      )}
                    >
                      {col.header}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {data.map((item) => {
                  const href = getRowHref?.(item);
                  return (
                    <tr
                      key={getRowId(item)}
                      onClick={() => href && (window.location.href = href)}
                      className={cn(
                        "border-b border-border/40 transition-colors hover:bg-accent/30",
                        href && "cursor-pointer",
                      )}
                    >
                      {columns.map((col) => (
                        <td
                          key={col.key}
                          className={cn(
                            "whitespace-nowrap px-4 py-3 text-sm",
                            col.align === "left" && "text-left",
                            col.align === "center" && "text-center",
                            col.className,
                          )}
                        >
                          {col.render(item)}
                        </td>
                      ))}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Mobile cards */}
          <div className="space-y-2 lg:hidden">
            {data.map((item) => {
              const href = getRowHref?.(item);
              const CardTag = href ? "a" : "div";
              return (
                <CardTag
                  key={getRowId(item)}
                  href={href}
                  className={cn(
                    "block rounded-xl border border-border bg-card p-3 transition-colors hover:bg-accent/30",
                    href && "cursor-pointer",
                  )}
                >
                  {columns
                    .filter((col) => !col.hideOnMobile)
                    .map((col, i) => (
                      <div
                        key={col.key}
                        className={cn(
                          "flex items-center justify-between gap-2 py-1",
                          i === 0 && "pb-2",
                          i > 0 && "border-t border-border/30 pt-1.5",
                        )}
                      >
                        <span className="text-xs text-muted-foreground">{col.header}</span>
                        <span className="text-sm font-medium text-foreground text-left">
                          {col.render(item)}
                        </span>
                      </div>
                    ))}
                </CardTag>
              );
            })}
          </div>
        </>
      )}

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between">
          <p className="text-sm text-muted-foreground nums-fa">
            مجموع: {toPersianDigits(total)} مورد
          </p>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="icon"
              onClick={() => onPageChange?.(page - 1)}
              disabled={page <= 1}
            >
              <ChevronRight className="size-4" />
            </Button>
            <span className="text-sm text-muted-foreground nums-fa">
              صفحه {toPersianDigits(page)} از {toPersianDigits(totalPages)}
            </span>
            <Button
              variant="outline"
              size="icon"
              onClick={() => onPageChange?.(page + 1)}
              disabled={page >= totalPages}
            >
              <ChevronLeft className="size-4" />
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}

export function StatusBadge({
  status,
  label,
  color,
}: {
  status: string;
  label: string;
  color: string;
}) {
  return (
    <span
      className="inline-flex items-center gap-1.5 rounded-full px-2 py-0.5 text-xs font-medium"
      style={{ backgroundColor: `${color}15`, color }}
    >
      <span className="size-1.5 rounded-full" style={{ backgroundColor: color }} />
      {label}
    </span>
  );
}

# اشکالات بک‌اند + پرامپت Claude

## پرامپت برای ارسال به Claude

کد زیر را کپی کرده و به Claude بفرستید:

---

```
من یک پروژه بک‌اند Express + Prisma دارم که API یک فروشگاه اینترنتی فارسی را ارائه می‌دهد. فرانت‌اند Next.js من با این بک‌اند کار می‌کند اما چند مشکل در پاسخ‌های API وجود دارد که باید اصلاح شود. لطفاً هر مورد را بررسی و اصلاح کنید.

## ۱. Brand و Category بدون URL تصویر
**مسیرهای تأثیرگذار:** `GET /brands`, `GET /brands/:id`, `GET /categories/tree`, `GET /categories/:id`

**مشکل:** بک‌اند فقط `logoId` و `imageId` برمی‌گرداند، نه URL آماده.

**راه‌حل:** در service، `logoUrl` و `imageUrl` را از روی `logoId`/`imageId` و جدول Media پر کنید:
```typescript
const brands = await prisma.brand.findMany({ include: { logo: true } });
return brands.map(b => ({ ...b, logoUrl: b.logo?.url ?? null }));
```

## ۲. WishlistItem.product ساختار ناقص
**مسیر:** `GET /wishlist`

**راه‌حل:** `product` را با `variants` و `images` کامل برگردانید.

## ۳. Comment بدون user object
**مسیر:** `GET /comments/product/:productId`

**راه‌حل:** `user: { select: { id, fullName, avatarUrl } }` را include کنید.

## ۴. sitemap.xml فقط URL خانه
**مسیر:** `GET /sitemap.xml`

**راه‌حل:** محصولات/دسته‌ها/برندهای فعال را اضافه کنید.

## ۵. ProductImage ساختار تودرتو
**مسیر:** `GET /products`, `GET /products/:slug`

**راه‌حل:** `url` و `alt` را flat روی `ProductImage` قرار دهید.

## ۶. ProductVariant.attributeValues ساختار junction
**مسیر:** `GET /products/:slug`

**راه‌حل:** attributeValues را flat کنید.

## ۷. Product.categories ساختار junction
**مسیر:** `GET /products`, `GET /products/:slug`

**راه‌حل:** `categories.map(pc => pc.category)` برای flat کردن.

## ۸. `GET /cart` شکل پاسخ
**مسیر:** `GET /cart`

**راه‌حل:** پاسخ را `{ cart, guestToken? }` تغییر دهید (مثل api.md).

## ۹. ADMIN ایجاد کاربر
**مسیر جدید:** `POST /api/v1/users/admin` (Auth: ADMIN)

**Body:** `{ fullName, identifier, password, role: "EDITOR" | "SUPPORT" | "ADMIN" }`

بدون OTP، رمز hash شده، ایمیل/موبایل تاییدشده.

## ۱۰. Stories (استوری) — endpoint جدید
**مسیر جدید:** `GET /api/v1/stories` (عمومی)

**Response:** `[{ id, title, imageUrl, link, expiresAt }]`

**مدل Prisma:**
```prisma
model Story {
  id          String   @id @default(cuid())
  title       String
  mediaId     String
  link        String?
  isActive    Boolean  @default(true)
  createdAt   DateTime @default(now())
  expiresAt   DateTime
  media       Media    @relation(fields: [mediaId], references: [id])
}
```

## ۱۱. Media — تگ‌گذاری و جست‌وجو + آپلود گروهی
**مسیرهای تأثیرگذار:** `GET /media`, `POST /media`, `POST /media/bulk`

**راه‌حل:**
1. فیلد `tags` (String[], آرایه رشته) به مدل Media اضافه کنید
2. `POST /media` و `POST /media/bulk` را پذیرنده فیلد `tags` کنید
3. `GET /media` را با `?search=` و `?tag=` فیلترپذیر کنید

## ۱۲. Blog — ماژول وبلاگ
**مسیرهای جدید:**
- `GET /api/v1/blog/posts?page=&limit=&category=&search=`
- `GET /api/v1/blog/posts/:slug`
- `POST /api/v1/blog/posts` (ADMIN/EDITOR)
- `PUT /api/v1/blog/posts/:id` (ADMIN/EDITOR)
- `DELETE /api/v1/blog/posts/:id` (ADMIN/EDITOR)
- `GET /api/v1/blog/categories`

**مدل Prisma:**
```prisma
model BlogPost {
  id          String   @id @default(cuid())
  title       String
  slug        String   @unique
  excerpt     String
  content     String
  categoryId  String?
  coverMediaId String?
  status      PostStatus @default(DRAFT)
  metaTitle   String?
  metaDescription String?
  publishedAt DateTime?
  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt
  category    BlogCategory? @relation(fields: [categoryId], references: [id])
  cover       Media?   @relation(fields: [coverMediaId], references: [id])
}

model BlogCategory {
  id    String @id @default(cuid())
  name  String
  slug  String @unique
  posts BlogPost[]
}

enum PostStatus {
  DRAFT
  PUBLISHED
  ARCHIVED
}
```

## ۱۳. Product detail by ID (public endpoint)
**مسیر جدید:** `GET /api/v1/products/by-id/:id`

**مشکل:** فعلاً فقط `GET /products/:slug` برای دسترسی عمومی وجود دارد. فرانت‌اند نیاز دارد URL با ID باشد و slug به‌عنوان query param برای SEO.

**راه‌حل:** یک endpoint عمومی اضافه کنید که محصول را با ID برگرداند (همان خروجی `GET /products/:slug`):

```typescript
// در product.routes.ts
router.get("/by-id/:id", productController.getById);

// در product.controller.ts
async getById(req, res) {
  const product = await productService.findById(req.params.id);
  // same serialization as bySlug
}
```

---

لطفاً هر مورد را در فایل مربوطه اصلاح کنید و تغییرات را ارائه دهید.
```

---

## خلاصه اشکالات

| # | اولویت | توضیح |
|---|--------|-------|
| ۱ | 🔴 بالا | Brand/Category بدون URL تصویر |
| ۲ | 🔴 بالا | WishlistItem.product ناقص |
| ۳ | 🔴 بالا | Comment بدون user object |
| ۴ | 🔴 بالا | sitemap فقط URL خانه |
| ۵ | 🟡 متوسط | ProductImage تودرتو |
| ۶ | 🟡 متوسط | attributeValues junction |
| ۷ | 🟡 متوسط | categories junction |
| ۸ | 🟡 متوسط | GET /cart شکل پاسخ |
| ۹ | 🔴 بالا | ADMIN ایجاد کاربر |
| ۱۰ | 🟡 متوسط | Stories endpoint |
| ۱۱ | 🟡 متوسط | Media tags + search + bulk |
| ۱۲ | 🔴 بالا | Blog module |

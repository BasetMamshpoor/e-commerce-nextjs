import Link from "next/link";
import {
  ArrowLeft,
  Truck,
  ShieldCheck,
  Headphones,
  CreditCard,
  Sparkles,
  Package,
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton, ProductGridSkeleton } from "@/components/common/loading-skeleton";
import { APP_NAME } from "@/constants/app";

export default function HomePage() {
  return (
    <div className="container-site py-6">
      {/* Hero */}
      <section className="relative mb-8 overflow-hidden rounded-2xl bg-gradient-to-l from-primary to-red-700 px-6 py-12 text-primary-foreground shadow-lg sm:px-12 sm:py-16">
        <div className="relative z-10 max-w-2xl">
          <span className="mb-4 inline-flex items-center gap-1.5 rounded-full bg-white/15 px-3 py-1 text-xs font-medium backdrop-blur">
            <Sparkles className="size-3.5" />
            جشنواره تابستانه
          </span>
          <h1 className="mb-4 text-3xl font-bold leading-tight sm:text-4xl lg:text-5xl">
            خریدی آسان، با تحویل سریع و پرداخت امن
          </h1>
          <p className="mb-6 text-base text-primary-foreground/90 sm:text-lg">
            از جدیدترین محصولات با بهترین قیمت‌ها در {APP_NAME} خرید کنید. ارسال
            رایگان برای سفارش‌های بالای ۵۰۰٬۰۰۰ تومان.
          </p>
          <div className="flex flex-wrap gap-3">
            <Button asChild size="lg" variant="secondary">
              <Link href="/products">
                مشاهده محصولات
                <ArrowLeft className="size-4" />
              </Link>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="border-white/30 bg-transparent text-primary-foreground hover:bg-white/10 hover:text-primary-foreground"
            >
              <Link href="/products?hasDiscount=true">تخفیف‌دارها</Link>
            </Button>
          </div>
        </div>
        {/* Decorative */}
        <div className="absolute -left-20 -top-20 size-72 rounded-full bg-white/10 blur-3xl" />
        <div className="absolute -bottom-32 left-1/3 size-96 rounded-full bg-white/5 blur-3xl" />
      </section>

      {/* Feature strip */}
      <section className="mb-10 grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-4">
        <FeatureCard
          icon={<Truck className="size-5" />}
          title="ارسال سریع"
          desc="تحویل در کوتاه‌ترین زمان"
        />
        <FeatureCard
          icon={<ShieldCheck className="size-5" />}
          title="ضمانت اصالت"
          desc="تضمین کالای اصل"
        />
        <FeatureCard
          icon={<CreditCard className="size-5" />}
          title="پرداخت امن"
          desc="درگاه‌های معتبر بانکی"
        />
        <FeatureCard
          icon={<Headphones className="size-5" />}
          title="پشتیبانی ۲۴/۷"
          desc="همیشه در کنار شما"
        />
      </section>

      {/* Categories placeholder */}
      <section className="mb-10">
        <SectionHeader title="دسته‌بندی‌های محبوب" href="/categories" />
        <div className="grid grid-cols-3 gap-3 sm:grid-cols-4 lg:grid-cols-6">
          {Array.from({ length: 6 }).map((_, i) => (
            <Skeleton key={i} className="aspect-square w-full rounded-xl" />
          ))}
        </div>
      </section>

      {/* Featured products placeholder */}
      <section className="mb-10">
        <SectionHeader title="محصولات منتخب" href="/products?isFeatured=true" />
        <ProductGridSkeleton count={8} />
      </section>

      {/* Discount products placeholder */}
      <section className="mb-10">
        <SectionHeader title="تخفیف‌های ویژه" href="/products?hasDiscount=true" />
        <ProductGridSkeleton count={4} />
      </section>

      {/* Newsletter placeholder */}
      <section className="mb-10 rounded-2xl bg-muted p-8 text-center">
        <Package className="mx-auto mb-3 size-10 text-primary" />
        <h2 className="mb-2 text-xl font-bold text-foreground">
          از جدیدترین تخفیف‌ها باخبر شوید
        </h2>
        <p className="mb-4 text-sm text-muted-foreground">
          عضو خبرنامه ما شوید و اولین نفری باشید که از فروش‌های ویژه مطلع می‌شود.
        </p>
        <Button variant="default">عضویت در خبرنامه</Button>
      </section>
    </div>
  );
}

function FeatureCard({
  icon,
  title,
  desc,
}: {
  icon: React.ReactNode;
  title: string;
  desc: string;
}) {
  return (
    <Card className="border-border/60 bg-card">
      <CardContent className="flex items-center gap-3 p-4">
        <div className="flex size-10 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary">
          {icon}
        </div>
        <div className="min-w-0">
          <div className="truncate text-sm font-semibold text-foreground">{title}</div>
          <div className="truncate text-xs text-muted-foreground">{desc}</div>
        </div>
      </CardContent>
    </Card>
  );
}

function SectionHeader({ title, href }: { title: string; href: string }) {
  return (
    <div className="mb-4 flex items-center justify-between">
      <h2 className="text-lg font-bold text-foreground sm:text-xl">{title}</h2>
      <Button asChild variant="ghost" size="sm" className="text-primary">
        <Link href={href}>
          مشاهده همه
          <ArrowLeft className="size-4" />
        </Link>
      </Button>
    </div>
  );
}

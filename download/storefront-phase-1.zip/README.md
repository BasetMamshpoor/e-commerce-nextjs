# فروشگاه اینترنتی Persian RTL — Frontend

> یک پروژه‌ی Next.js 16 (App Router) برای یک فروشگاه اینترنتی فارسی کاملاً RTL،
> مبتنی بر مستندات API در `api.md` و `README.md`.

این شاخه شامل **فاز ۱ (Foundation & Infrastructure)** است.

---

## پشته‌ی فناوری

| لایه | فناوری |
|------|--------|
| Framework | Next.js 16 (App Router, Turbopack) |
| Language | TypeScript 5 (strict) |
| Styling | Tailwind CSS v4 + shadcn/ui (New York) |
| State (server) | TanStack Query v5 |
| State (client) | React Context (auth, cart) |
| HTTP | Axios (با interceptors و refresh-token rotation) |
| Forms | React Hook Form + Zod |
| Animation | Framer Motion |
| Map | React Leaflet |
| Rich Text | TipTap |
| Theme | next-themes (light/dark) |
| Icons | Lucide |
| Font | Vazirmatn (variable, self-hosted) |

---

## ساختار پوشه‌ها

```
.
├── app/
│   ├── (site)/                 ← Storefront (header + footer)
│   │   ├── layout.tsx
│   │   ├── page.tsx            ← Home page
│   │   ├── loading.tsx
│   │   ├── error.tsx
│   │   └── not-found.tsx
│   ├── admin/                  ← Admin panel (full-screen, no chrome)
│   │   ├── layout.tsx
│   │   └── page.tsx
│   ├── fonts/                  ← Vazirmatn woff2 (self-hosted)
│   ├── globals.css             ← Centralized CSS variables (Digikala red)
│   └── layout.tsx              ← Root: RTL, providers, font, theme
├── api/
│   └── endpoints.ts            ← All API routes (mirror of api.md)
├── components/
│   ├── ui/                     ← shadcn/ui (50+ components)
│   ├── providers/              ← ThemeProvider, QueryProvider
│   ├── site/                   ← Header, Footer, ThemeToggle, CartBadge
│   └── common/                 ← EmptyState, ErrorState, Skeleton, PersianNumber
├── constants/
│   └── app.ts                  ← APP_CONFIG (URLs, storage keys, etc.)
├── hooks/                      ← useToast, useMobile + future api hooks
├── lib/
│   ├── api-client.ts           ← Axios instance + interceptors + token mgmt
│   ├── query-client.ts         ← React Query client factory
│   ├── utils.ts                ← cn() helper
│   └── db.ts                   ← (unused in Phase 1; ready for future use)
├── providers/
│   ├── auth-context.tsx        ← useAuth() — session, user, login/logout
│   └── cart-context.tsx        ← useCart() — item count, guest token
├── services/                   ← 24 typed service files (one per API module)
│   ├── auth.service.ts
│   ├── categories.service.ts
│   ├── brands.service.ts
│   ├── attributes.service.ts
│   ├── products.service.ts
│   ├── cart.service.ts
│   ├── wishlist.service.ts
│   ├── comparison.service.ts
│   ├── discount-codes.service.ts
│   ├── addresses.service.ts
│   ├── shipping.service.ts
│   ├── payments.service.ts
│   ├── wallet.service.ts
│   ├── orders.service.ts
│   ├── media.service.ts
│   ├── notifications.service.ts
│   ├── tickets.service.ts
│   ├── comments.service.ts
│   ├── banners.service.ts
│   ├── popups.service.ts
│   ├── users-admin.service.ts
│   ├── security.service.ts
│   ├── analytics.service.ts
│   ├── users-me.service.ts
│   ├── settings.service.ts
│   └── index.ts                ← Barrel export
├── types/
│   ├── api.ts                  ← ApiResponse, PaginatedData, ApiError
│   └── domain.ts               ← All entity types (User, Product, Order, ...)
├── utils/
│   └── format.ts               ← Persian digits, currency, dates, phone
├── public/
│   └── (logo, robots, etc.)
├── .env                        ← NEXT_PUBLIC_API_BASE_URL etc.
├── components.json             ← shadcn/ui config (root paths)
├── next.config.ts              ← Rewrites: /sitemap.xml, /robots.txt, /uploads/*
├── package.json
├── tsconfig.json               ← @/* → ./* (no src/)
└── README.md                   ← This file
```

---

## راه‌اندازی

### ۱. نصب وابستگی‌ها

```bash
bun install
```

### ۲. پیکربندی `.env`

فایل `.env` در ریشه‌ی پروژه با مقادیر زیر:

```env
NEXT_PUBLIC_API_BASE_URL=http://localhost:4000/api/v1
NEXT_PUBLIC_BACKEND_ROOT_URL=http://localhost:4000
NEXT_PUBLIC_PUBLIC_SITE_URL=http://localhost:3000
NEXT_PUBLIC_DEFAULT_PAGE_SIZE=20
```

### ۳. اجرای dev server

```bash
bun run dev
```

سپس به `http://localhost:3000` بروید.

### ۴. اتصال به بک‌اند

بک‌اند باید روی `http://localhost:4000` در حال اجرا باشد. در صورت عدم اتصال،
صفحه بدون خطا لود می‌شود ولی ویژگی‌های داینامیک (محصولات، سبد خرید و...)
خالی یا skeleton نمایش می‌دهند.

---

## ویژگی‌های پیاده‌سازی‌شده در فاز ۱

### ✅ زیرساخت

- **RTL کامل**: `<html dir="rtl" lang="fa">` در root layout
- **فونت Vazirmatn**: self-hosted به‌صورت woff2 variable، با fallback به Tahoma
- **سیستم رنگ متمرکز**: تمام رنگ‌ها (primary, accent, background, ...) به‌صورت
  CSS variables در `app/globals.css` — تغییر برند فقط با ویرایش چند خط
- **Light/Dark mode**: با next-themes، toggle در header
- **Tailwind v4 + shadcn/ui**: 50+ کامپوننت آماده در `components/ui/`

### ✅ API Layer

- **Axios instance** با:
  - Request interceptor: تزریق خودکار `Authorization` و `X-Guest-Token`
  - Response interceptor: unwarp `{success, data}` + تبدیل خطا به `ApiError`
  - **Refresh-token rotation**: در 401، یک‌بار خودکار refresh و retry
  - SSR-safe (بدون localStorage در server)
- **24 فایل سرویس**: هر ماژول API یک فایل با توابع تایپ‌شده
- **endpoints.ts**: همه‌ی مسیرها در یک فایل مرکزی
- **types/domain.ts**: تمام تایپ‌های entity (~700 خط)

### ✅ State Management

- **AuthProvider**: session، user، isAuthenticated، applySession، clearLocalSession
- **CartProvider**: itemCount (synced با React Query cache)، guest token
- **QueryProvider**: با devtools در development
- **Auto cart merge**: پس از login، `POST /cart/merge` خودکار صدا زده می‌شود

### ✅ UI پایه

- **Header**: لوگو، جست‌وجو، nav دسته‌بندی، cart badge، theme toggle، auth link، mobile menu (Sheet)
- **Footer**: 4 ستون با لینک‌های سریع، شبکه‌های اجتماعی، اطلاعات تماس
- **Home page**: hero، feature strip، skeleton‌های placeholder برای دسته/محصولات
- **Loading skeleton**, **Error state**, **Empty state**, **Not-found page**
- **PersianNumber**: کامپوننت برای نمایش اعداد فارسی
- **utils/format.ts**: تبدیل اعداد، قیمت، تاریخ Jalali، موبایل، جمع‌بندی

### ✅ Admin shell

- مسیر `/admin/*` با layout جدا (بدون header/footer سایت)
- فعلاً placeholder؛ در **فاز ۸** پیاده‌سازی کامل

### ✅ SEO & Performance

- **Metadata API**: title template، description، keywords، OpenGraph، Twitter، robots
- **next.config.ts rewrites**: proxy `/sitemap.xml`، `/robots.txt`، `/uploads/*` به بک‌اند
- **Viewport**: themeColor برای light/dark
- **next/font/local**: Vazirmatn با display: swap

---

## نقشه‌ی فازهای بعدی

| فاز | محتوا |
|-----|-------|
| 2 | Auth (login/register/OTP/forgot/reset) |
| 3 | Catalog (home real data, categories tree, product listing, product detail) |
| 4 | Cart, Wishlist, Comparison |
| 5 | Checkout + Orders |
| 6 | User account (profile, wallet, addresses, tickets, notifications) |
| 7 | Comments & Reviews |
| 8 | Admin panel (full) |
| 9 | SEO completion + performance optimization |
| 10 | Polish, animations, a11y audit |

---

## اسکریپت‌های npm

```bash
bun run dev      # Dev server on port 3000
bun run build    # Production build (standalone)
bun run start    # Run production server
bun run lint     # ESLint
```

import Link from "next/link";
import { Phone, Mail, MapPin, Instagram, Send } from "lucide-react";

import { APP_NAME, APP_DESCRIPTION } from "@/constants/app";

export function Footer() {
  return (
    <footer className="mt-auto border-t border-border bg-card">
      <div className="container-site py-12">
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
          {/* Brand */}
          <div className="space-y-3">
            <h3 className="text-base font-bold text-foreground">{APP_NAME}</h3>
            <p className="text-sm text-muted-foreground">{APP_DESCRIPTION}</p>
            <div className="flex items-center gap-2">
              <a
                href="#"
                aria-label="اینستاگرام"
                className="flex size-9 items-center justify-center rounded-md bg-muted text-muted-foreground transition-colors hover:bg-primary hover:text-primary-foreground"
              >
                <Instagram className="size-4" />
              </a>
              <a
                href="#"
                aria-label="تلگرام"
                className="flex size-9 items-center justify-center rounded-md bg-muted text-muted-foreground transition-colors hover:bg-primary hover:text-primary-foreground"
              >
                <Send className="size-4" />
              </a>
            </div>
          </div>

          {/* Quick links */}
          <nav className="space-y-3">
            <h4 className="text-sm font-semibold text-foreground">خدمات مشتریان</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><Link href="/about" className="hover:text-foreground">درباره ما</Link></li>
              <li><Link href="/contact" className="hover:text-foreground">تماس با ما</Link></li>
              <li><Link href="/tickets" className="hover:text-foreground">پشتیبانی</Link></li>
              <li><Link href="/faq" className="hover:text-foreground">سوالات متداول</Link></li>
            </ul>
          </nav>

          {/* Policies */}
          <nav className="space-y-3">
            <h4 className="text-sm font-semibold text-foreground">قوانین و مقررات</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><Link href="/privacy" className="hover:text-foreground">حریم خصوصی</Link></li>
              <li><Link href="/terms" className="hover:text-foreground">شرایط استفاده</Link></li>
              <li><Link href="/shipping-policy" className="hover:text-foreground">سیاست ارسال</Link></li>
              <li><Link href="/returns" className="hover:text-foreground">مرجوعی کالا</Link></li>
            </ul>
          </nav>

          {/* Contact */}
          <div className="space-y-3">
            <h4 className="text-sm font-semibold text-foreground">اطلاعات تماس</h4>
            <ul className="space-y-3 text-sm text-muted-foreground">
              <li className="flex items-center gap-2">
                <Phone className="size-4 text-primary" />
                <span>۰۲۱-۱۲۳۴۵۶۷۸</span>
              </li>
              <li className="flex items-center gap-2">
                <Mail className="size-4 text-primary" />
                <span>support@example.com</span>
              </li>
              <li className="flex items-center gap-2">
                <MapPin className="size-4 text-primary" />
                <span>تهران، ایران</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-10 flex flex-col items-center justify-between gap-4 border-t border-border pt-6 text-xs text-muted-foreground sm:flex-row">
          <p>© {new Intl.DateTimeFormat("fa-IR", { year: "numeric" }).format(new Date())} {APP_NAME}. تمامی حقوق محفوظ است.</p>
          <div className="flex items-center gap-4">
            <span>طراحی و توسعه با ❤</span>
          </div>
        </div>
      </div>
    </footer>
  );
}

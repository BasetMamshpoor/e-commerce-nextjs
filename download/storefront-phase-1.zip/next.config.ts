import type { NextConfig } from "next";

const backendRoot = process.env.NEXT_PUBLIC_BACKEND_ROOT_URL ?? "http://localhost:4000";

const nextConfig: NextConfig = {
  output: "standalone",
  reactStrictMode: false,
  typescript: {
    ignoreBuildErrors: true,
  },
  images: {
    remotePatterns: [
      {
        protocol: "http",
        hostname: "localhost",
        port: "4000",
      },
      {
        protocol: "https",
        hostname: "**",
      },
    ],
  },
  // Proxy /sitemap.xml and /robots.txt to backend (Phase 9 will also generate
  // Next.js-native sitemaps, but until then we proxy the backend's).
  async rewrites() {
    return [
      { source: "/sitemap.xml", destination: `${backendRoot}/sitemap.xml` },
      { source: "/robots.txt", destination: `${backendRoot}/robots.txt` },
      // Proxy /uploads/* so backend-served media URLs work seamlessly.
      { source: "/uploads/:path*", destination: `${backendRoot}/uploads/:path*` },
    ];
  },
};

export default nextConfig;

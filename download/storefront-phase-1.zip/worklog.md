# Worklog — Persian RTL E-Commerce Frontend

---
Task ID: phase-1
Agent: main (Super Z)
Task: Build Phase 1 — Foundation & Infrastructure for Persian RTL Next.js 16 e-commerce frontend based on api.md and README.md backend docs.

Work Log:
- Read /home/z/my-project/upload/API.md (1122 lines) and README.md fully
- Captured user requirements:
  - Backend URL: http://localhost:4000/api/v1 (live)
  - Rich text editor: TipTap
  - Color palette: Digikala-inspired red (#ef3a4b)
  - Font: Vazirmatn (self-hosted variable woff2)
  - Admin: same Next.js app under /admin/* with separate layout (no site chrome)
  - NO src/ folder — flat root structure
  - app/(site) for storefront, app/admin for admin panel
- Initialized fullstack-dev project (Next.js 16 + Tailwind v4 + shadcn/ui)
- Restructured project: moved src/{app,components,hooks,lib} to root level
- Updated tsconfig.json paths (@/* → ./*), components.json (root paths), next.config.ts (rewrites for sitemap/robots/uploads proxy)
- Installed: axios, leaflet, react-leaflet, @tiptap/react, @tiptap/starter-kit, @tiptap/extension-image, @tiptap/extension-link, @tiptap/extension-text-align, @tiptap/extension-placeholder, @tiptap/pm, @types/leaflet
- Downloaded Vazirmatn v33.003 and placed variable woff2 at app/fonts/
- Built app/globals.css: Tailwind v4 + centralized CSS variables (Digikala red palette), light + dark themes, custom scrollbar, container utilities, shimmer animation
- Built app/layout.tsx: RTL html, Vazirmatn localFont, ThemeProvider → QueryProvider → AuthProvider → CartProvider → Toaster + SonnerToaster
- Built app/(site)/layout.tsx: Header + main + Footer (sticky footer pattern)
- Built app/(site)/page.tsx: home page with hero, feature strip, skeleton placeholders
- Built app/(site)/loading.tsx, error.tsx, not-found.tsx
- Built app/admin/layout.tsx: full-screen admin shell (no site header/footer)
- Built app/admin/page.tsx: dashboard placeholder
- Built constants/app.ts: APP_CONFIG with apiBaseUrl, storageKeys, etc.
- Built types/api.ts: ApiSuccessResponse, ApiErrorResponse, PaginatedData, ApiError class with helpers (isUnauthorized, isRateLimited, isBlocked, etc.)
- Built types/domain.ts: ~700 lines covering ALL entities from api.md (User, Category, Brand, Attribute, Product, Variant, Cart, WishlistItem, Comparison, DiscountCode, Address, ShippingCompany, PaymentGateway, Wallet, Order, Media, Notification, Ticket, Comment, Banner, Popup, Setting, Analytics, BlockedIp)
- Built api/endpoints.ts: every endpoint path from api.md organized by module
- Built lib/api-client.ts: axios instance + request interceptor (auth+guest headers) + response interceptor (unwrap envelope + 401 auto-refresh with token rotation + ApiError mapping) + token storage helpers + hydrateSession + persistSession + getCachedUser + subscribeTokens
- Built lib/query-client.ts: QueryClient factory with retry rules, staleTime, gcTime
- Built providers/auth-context.tsx: useAuth() with user, isLoading, isAuthenticated, applySession, clearLocalSession; auto-fetches /users/me on mount if token exists; listens for auth:session-expired events
- Built providers/cart-context.tsx: useCart() with itemCount synced to React Query cache; auto-merges guest cart on login
- Built 24 service files (one per API module) + index.ts barrel export
- Built utils/format.ts: toPersianDigits, toEnglishDigits, formatPrice, formatToman, formatTomanShort, discountPercent, formatDateFa, formatDateTimeFa, formatRelativeFa, normalizePhone, formatPhone, isValidIranMobile, isValidEmail, pluralizeFa, withCountFa
- Built components/providers/theme-provider.tsx, query-provider.tsx
- Built components/site/header.tsx (logo, search, nav, cart badge, theme toggle, mobile sheet), footer.tsx, theme-toggle.tsx, cart-badge.tsx
- Built components/common/empty-state.tsx, error-state.tsx, loading-skeleton.tsx (Skeleton, LoadingSkeleton, ProductGridSkeleton), persian-number.tsx
- Updated .env with NEXT_PUBLIC_API_BASE_URL, NEXT_PUBLIC_BACKEND_ROOT_URL, NEXT_PUBLIC_PUBLIC_SITE_URL
- Ran `bun run lint` — 0 errors, fixed 1 unused eslint-disable warning
- Verified dev server running on port 3000 (Next.js 16.1.3 Turbopack)
- Verified with agent-browser: home page renders correctly with RTL, Persian text, header/footer; theme toggle works; mobile viewport 375x812 responsive; /admin route renders without site chrome; no console errors
- Wrote comprehensive README.md with stack, structure, setup, phase 1 features, and roadmap

Stage Summary:
- Phase 1 complete. Project is a fully-functional Next.js 16 RTL Persian foundation with:
  - Centralized color system (Digikala red), light/dark theme
  - Vazirmatn font self-hosted
  - Complete typed API layer (axios + interceptors + refresh-token rotation)
  - React Query setup with devtools
  - Auth + Cart context providers
  - 24 service modules + types for all 26 API sections
  - Site shell (header + footer) with mobile menu, search, theme toggle, cart badge
  - Admin shell (full-screen, separate layout)
  - Home page placeholder with hero + skeleton sections
  - Loading/error/empty/not-found states
  - Persian formatting utilities (digits, currency, dates, phone)
- Dev server running cleanly. Lint passes. Browser-verified at / and /admin.
- Ready for Phase 2 (Auth) on user approval.
- ZIP will be generated at /home/z/my-project/download/storefront-phase-1.zip
